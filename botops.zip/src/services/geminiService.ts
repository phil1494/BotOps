import { GoogleGenAI, Type } from "@google/genai";
import { BotAnalysis, CodeGeneration } from "../types";

console.log("DEBUG: Key Check ->", import.meta.env.VITE_GEMINI_API_KEY ? "Vorhanden" : "FEHLT!");

export async function analyzeBotLog(log: string): Promise<BotAnalysis> {
  try {
    const apiKey = import.meta.env.VITE_GEMINI_API_KEY;
    if (!apiKey) {
      throw new Error("GEMINI_API_KEY is missing.");
    }
    const ai = new GoogleGenAI({ apiKey });
    
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: [{ role: "user", parts: [{ text: `Analysiere diesen Discord-Bot-Log: \n\n${log}` }] }],
      config: {
        systemInstruction: `Du bist das Backend-Gehirn für "BotOps", ein Discord-Bot-Monitoring-System.
Deine Aufgabe ist es, eingehende Status-Updates und Fehlermeldungen von Discord-Bots zu analysieren.

REGELN FÜR DEINEN OUTPUT:
1. Antworte IMMER im strukturierten JSON-Format.
2. Analysiere Fehler-Logs (Tracebacks) und erkläre die Ursache in einfachem Deutsch.
3. Gib konkrete Handlungsanweisungen (z.B. "Prüfe die Berechtigungen für 'Send Messages'").
4. Wenn der Fehler durch eine Code-Änderung behoben werden kann, gib einen kurzen, korrekten Code-Snippet in 'suggested_fix_code' an.
5. Berechne einen "Health Score" von 0-100 basierend auf Fehlerrate und Uptime.`,
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            bot_status: {
              type: Type.STRING,
              enum: ["error", "online", "warning"],
              description: "Der aktuelle Status des Bots."
            },
            analysis: {
              type: Type.STRING,
              description: "Erklärung der Ursache in einfachem Deutsch."
            },
            fix_steps: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
              description: "Konkrete Handlungsanweisungen."
            },
            suggested_fix_code: {
              type: Type.STRING,
              description: "Ein optionaler Code-Snippet zur Behebung des Fehlers."
            },
            health_score: {
              type: Type.NUMBER,
              description: "Health Score von 0-100."
            },
            stats_insight: {
              type: Type.STRING,
              description: "Ein kurzer Satz zum Server-Wachstum oder Trends."
            }
          },
          required: ["bot_status", "analysis", "fix_steps", "health_score", "stats_insight"]
        }
      }
    });

    return JSON.parse(response.text);
  } catch (error) {
    console.error("Analysis error:", error);
    return {
      bot_status: "error",
      analysis: "Fehler bei der Analyse des Logs. Bitte versuche es erneut.",
      fix_steps: ["Überprüfe die Internetverbindung", "Versuche es später erneut"],
      health_score: 0,
      stats_insight: "Keine Daten verfügbar."
    };
  }
}

export async function generateMoodSummary(logs: string): Promise<string> {
  try {
    const apiKey = import.meta.env.VITE_GEMINI_API_KEY;
    if (!apiKey) return "Status unbekannt";
    const ai = new GoogleGenAI({ apiKey });

    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: [{ role: "user", parts: [{ text: `Basierend auf diesen Logs, gib eine extrem kurze (max 10 Wörter) "Stimmungs-Zusammenfassung" für den Bot ab.
Beispiele: "Läuft stabil", "Häufige Timeouts", "Berechtigungsprobleme erkannt".

Logs:
${logs}` }] }]
    });
    return response.text.trim();
  } catch (error) {
    return "Status unbekannt";
  }
}

export async function generateSecurityChecklist(botInfo: any): Promise<string[]> {
  try {
    const apiKey = import.meta.env.VITE_GEMINI_API_KEY;
    if (!apiKey) return ["Token geheim halten", "Berechtigungen minimieren"];
    const ai = new GoogleGenAI({ apiKey });

    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: [{ role: "user", parts: [{ text: `Erstelle eine kurze Sicherheits-Checkliste für einen Discord-Bot mit diesen Daten:
${JSON.stringify(botInfo)}

Fokus: Berechtigungen, Token-Sicherheit, Best Practices. Max 4 Punkte.` }] }],
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            checklist: { type: Type.ARRAY, items: { type: Type.STRING } }
          },
          required: ["checklist"]
        }
      }
    });
    const data = JSON.parse(response.text);
    return data.checklist;
  } catch (error) {
    return ["Token geheim halten", "Berechtigungen minimieren"];
  }
}

export async function generateBotCode(userRequest: string, context: { language?: string, botName: string }): Promise<CodeGeneration> {
  try {
    const apiKey = import.meta.env.VITE_GEMINI_API_KEY;
    if (!apiKey) throw new Error("API Key fehlt");
    const ai = new GoogleGenAI({ apiKey });

    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: [{ role: "user", parts: [{ text: `Generiere Code für einen Discord-Bot basierend auf dieser Anfrage: "${userRequest}"
Bot-Name: ${context.botName}
Bevorzugte Sprache: ${context.language || "discord.js (JavaScript)"}

Gib den Code, eine kurze Erklärung und die Sprache im JSON-Format zurück.` }] }],
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            code: { type: Type.STRING },
            explanation: { type: Type.STRING },
            language: { type: Type.STRING }
          },
          required: ["code", "explanation", "language"]
        }
      }
    });
    return JSON.parse(response.text);
  } catch (error) {
    throw new Error("Fehler bei der Code-Generierung");
  }
}
