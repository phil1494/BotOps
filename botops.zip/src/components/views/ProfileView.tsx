import { motion } from "motion/react";
import { User, Mail, Shield, Calendar, MapPin, Edit3, Settings, Moon, ChevronRight } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

interface ProfileViewProps {
  user: any;
  t: any;
}

export function ProfileView({ user, t }: ProfileViewProps) {
  return (
    <div className="max-w-4xl mx-auto space-y-8">
      <div className="flex flex-col md:flex-row items-start md:items-center gap-6">
        <div className="relative group">
          <Avatar className="h-24 w-24 border-4 border-primary/20 group-hover:border-primary/50 transition-all">
            <AvatarImage src={user?.user_metadata?.avatar_url || ""} />
            <AvatarFallback className="bg-primary/10 text-primary text-2xl font-bold">
              {user?.user_metadata?.full_name?.substring(0, 2).toUpperCase() || "US"}
            </AvatarFallback>
          </Avatar>
          <div className="absolute bottom-0 right-0 p-1.5 bg-primary rounded-full border-2 border-[#050505] cursor-pointer hover:scale-110 transition-transform">
            <Edit3 className="w-3 h-3 text-white" />
          </div>
        </div>
        <div className="flex-1">
          <h2 className="text-3xl font-bold text-white tracking-tight">{user?.user_metadata?.full_name || t.user_name || "User Name"}</h2>
          <p className="text-slate-400 flex items-center gap-2 mt-1">
            <Mail className="w-4 h-4" />
            {user?.email || "user@example.com"}
          </p>
          <div className="flex gap-2 mt-4">
            <Badge className="bg-primary/20 text-primary border-primary/30">Admin</Badge>
            <Badge variant="outline" className="border-white/10 text-slate-400">Pro Plan</Badge>
          </div>
        </div>
        <Button className="btn-gradient px-6 font-bold">
          {t.edit_profile}
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="card-glass border-white/5 bg-white/[0.01]">
          <CardHeader className="pb-2">
            <CardTitle className="text-xs font-bold text-slate-500 uppercase tracking-widest flex items-center gap-2">
              <Shield className="w-3.5 h-3.5" />
              {t.security_status}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-lg font-bold text-emerald-400">{t.verified}</p>
            <p className="text-[10px] text-slate-500 mt-1">2FA is currently enabled</p>
          </CardContent>
        </Card>
        <Card className="card-glass border-white/5 bg-white/[0.01]">
          <CardHeader className="pb-2">
            <CardTitle className="text-xs font-bold text-slate-500 uppercase tracking-widest flex items-center gap-2">
              <Calendar className="w-3.5 h-3.5" />
              {t.member_since}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-lg font-bold text-white">April 2024</p>
            <p className="text-[10px] text-slate-500 mt-1">Active for 12 months</p>
          </CardContent>
        </Card>
        <Card className="card-glass border-white/5 bg-white/[0.01]">
          <CardHeader className="pb-2">
            <CardTitle className="text-xs font-bold text-slate-500 uppercase tracking-widest flex items-center gap-2">
              <MapPin className="w-3.5 h-3.5" />
              {t.location}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-lg font-bold text-white">Europe</p>
            <p className="text-[10px] text-slate-500 mt-1">Primary Access Point</p>
          </CardContent>
        </Card>
      </div>

      <Card className="card-glass border-white/5 bg-white/[0.01]">
        <CardHeader>
          <CardTitle className="text-sm font-bold uppercase tracking-widest text-white">{t.account_activity}</CardTitle>
          <CardDescription>{t.recent_actions}</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {[
            { action: t.logged_in_new_device || "Logged in from new device", time: "2 hours ago", icon: Shield },
            { action: t.updated_tracking_key || "Updated bot tracking key", time: "5 hours ago", icon: Settings },
            { action: t.changed_theme_dark || "Changed theme to Dark Mode", time: "1 day ago", icon: Moon },
          ].map((item, i) => (
            <div key={i} className="flex items-center justify-between p-3 bg-white/5 rounded-xl border border-white/5">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center">
                  <item.icon className="w-4 h-4 text-primary" />
                </div>
                <div>
                  <p className="text-xs font-bold text-white">{item.action}</p>
                  <p className="text-[10px] text-slate-500">{item.time}</p>
                </div>
              </div>
              <ChevronRight className="w-4 h-4 text-slate-700" />
            </div>
          ))}
        </CardContent>
      </Card>
    </div>
  );
}
