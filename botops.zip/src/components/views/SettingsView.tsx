import React, { useState, useEffect } from "react";
import { 
  Settings as SettingsIcon, 
  Key, 
  Bell, 
  Shield, 
  Database,
  Moon,
  Globe,
  Mail,
  Lock,
  Eye,
  EyeOff,
  CheckCircle2,
  AlertCircle,
  Sun,
  Send
} from "lucide-react";
import { cn } from "@/lib/utils";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { supabase } from "@/src/lib/supabaseClient";

import { Language } from "@/src/lib/translations";

export function SettingsView({ 
  onClearData, 
  highContrast, 
  setHighContrast,
  language,
  setLanguage,
  t
}: { 
  onClearData: () => void,
  highContrast: boolean,
  setHighContrast: (val: boolean) => void,
  language: Language,
  setLanguage: (lang: Language) => void,
  t: any
}) {
  const [user, setUser] = useState<any>(null);
  const [newPassword, setNewPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [isUpdating, setIsUpdating] = useState(false);
  const [message, setMessage] = useState<{ type: 'success' | 'error', text: string } | null>(null);

  // Webhook State
  const [webhookUrl, setWebhookUrl] = useState("");
  const [isTestingWebhook, setIsTestingWebhook] = useState(false);
  const [webhookMessage, setWebhookMessage] = useState<{ type: 'success' | 'error', text: string } | null>(null);

  useEffect(() => {
    supabase.auth.getUser().then(({ data: { user } }) => {
      setUser(user);
    });

    // Load Webhook from localStorage
    const savedWebhook = localStorage.getItem("botops_webhook_url");
    if (savedWebhook) setWebhookUrl(savedWebhook);
  }, []);

  const handleSaveWebhook = () => {
    localStorage.setItem("botops_webhook_url", webhookUrl);
    setWebhookMessage({ type: 'success', text: t.webhook_saved });
    setTimeout(() => setWebhookMessage(null), 3000);
  };

  const handleTestWebhook = async () => {
    if (!webhookUrl) return;
    setIsTestingWebhook(true);
    setWebhookMessage(null);
    try {
      const response = await fetch(webhookUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          embeds: [{
            title: `✅ ${t.webhook_connected}`,
            description: t.webhook_desc,
            color: 0x3b82f6,
            timestamp: new Date().toISOString(),
            footer: { text: "BotOps Intelligence Integration" }
          }]
        })
      });
      if (!response.ok) throw new Error(t.webhook_error);
      setWebhookMessage({ type: 'success', text: t.webhook_test_success });
    } catch (err: any) {
      setWebhookMessage({ type: 'error', text: err.message || t.webhook_error });
    } finally {
      setIsTestingWebhook(false);
      setTimeout(() => setWebhookMessage(null), 5000);
    }
  };

  const handleUpdatePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPassword) return;
    setIsUpdating(true);
    setMessage(null);
    try {
      const { error } = await supabase.auth.updateUser({ password: newPassword });
      if (error) throw error;
      setMessage({ type: 'success', text: t.password_updated });
      setNewPassword("");
    } catch (err: any) {
      setMessage({ type: 'error', text: err.message });
    } finally {
      setIsUpdating(false);
    }
  };

  return (
    <div className={`max-w-4xl mx-auto space-y-8 ${highContrast ? 'contrast-125' : ''}`}>
      <div>
        <h2 className="text-3xl font-bold text-white tracking-tight">{t.settings}</h2>
        <p className="text-slate-400 mt-1">{t.settings_desc}</p>
      </div>

      <div className="grid gap-6">
        {/* Account Profile */}
        <Card className="card-glass">
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2 text-white">
              <Mail className="w-5 h-5 text-primary" />
              {t.profile}
            </CardTitle>
            <CardDescription className="text-slate-400">{t.profile_desc}</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="p-4 bg-white/5 rounded-xl border border-white/5 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center border border-primary/30">
                  <span className="text-primary font-bold">{user?.email?.[0].toUpperCase()}</span>
                </div>
                <div>
                  <p className="text-sm font-medium text-white">{user?.email}</p>
                  <p className="text-[10px] text-slate-400 uppercase tracking-widest">User ID: {user?.id?.substring(0, 8)}...</p>
                </div>
              </div>
              <Badge className="bg-emerald-500/10 text-emerald-500 border-emerald-500/20">{t.verified}</Badge>
            </div>
          </CardContent>
        </Card>

        {/* Security / Password */}
        <Card className="card-glass">
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2 text-white">
              <Lock className="w-5 h-5 text-amber-500" />
              {t.security}
            </CardTitle>
            <CardDescription className="text-slate-400">{t.security_desc}</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleUpdatePassword} className="space-y-4">
              <div className="space-y-2">
                <label className="text-xs font-bold text-slate-400 uppercase tracking-widest">{t.new_password}</label>
                <div className="flex gap-3">
                  <div className="relative flex-1">
                    <Input 
                      type={showPassword ? "text" : "password"} 
                      placeholder={t.enter_password} 
                      className="bg-black/40 border-white/10 pr-10 text-white h-11"
                      value={newPassword}
                      onChange={(e) => setNewPassword(e.target.value)}
                    />
                    <button 
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-500 hover:text-white"
                    >
                      {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                  <Button 
                    type="submit" 
                    className="btn-gradient h-11 px-6 font-bold"
                    disabled={isUpdating || !newPassword}
                  >
                    {isUpdating ? t.updating : t.change_password}
                  </Button>
                </div>
              </div>
              {message && (
                <div className={`p-3 rounded-lg flex items-center gap-3 text-xs ${
                  message.type === 'success' ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20' : 'bg-rose-500/10 text-rose-400 border border-rose-500/20'
                }`}>
                  {message.type === 'success' ? <CheckCircle2 className="w-4 h-4" /> : <AlertCircle className="w-4 h-4" />}
                  {message.text}
                </div>
              )}
            </form>
          </CardContent>
        </Card>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Appearance */}
          <Card className="card-glass">
            <CardHeader>
              <CardTitle className="text-sm font-bold flex items-center gap-2 text-white">
                <Moon className="w-4 h-4 text-indigo-400" />
                {t.appearance}
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-white">{t.high_contrast}</p>
                  <p className="text-[10px] text-slate-400">{t.high_contrast_desc}</p>
                </div>
                <button 
                  onClick={() => setHighContrast(!highContrast)}
                  className={`w-10 h-5 rounded-full transition-colors relative ${highContrast ? 'bg-primary' : 'bg-white/10'}`}
                >
                  <div className={`absolute top-1 w-3 h-3 rounded-full bg-white transition-all ${highContrast ? 'left-6' : 'left-1'}`} />
                </button>
              </div>
              
              <div className="pt-4 border-t border-white/5 space-y-3">
                <p className="text-xs font-bold text-slate-400 uppercase tracking-widest">{t.quick_language}</p>
                <div className="grid grid-cols-2 gap-2">
                  {[
                    { id: 'en', label: 'English', flag: '🇺🇸' },
                    { id: 'de', label: 'Deutsch', flag: '🇩🇪' },
                    { id: 'es', label: 'Español', flag: '🇪🇸' }
                  ].map((lang) => (
                    <Button
                      key={lang.id}
                      variant="outline"
                      size="sm"
                      className={cn(
                        "h-9 justify-start gap-2 bg-white/5 border-white/5 text-xs",
                        language === lang.id ? "border-primary/50 bg-primary/10 text-white" : "text-slate-400 hover:text-white"
                      )}
                      onClick={() => setLanguage(lang.id as Language)}
                    >
                      <span>{lang.flag}</span>
                      {lang.label}
                    </Button>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="card-glass">
            <CardHeader>
              <CardTitle className="text-sm font-bold flex items-center gap-2 text-white">
                <Shield className="w-4 h-4 text-primary" />
                {t.privacy}
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-white">{t.token_masking}</p>
                  <p className="text-[10px] text-slate-400">{t.token_masking_desc}</p>
                </div>
                <Badge className="bg-emerald-500/10 text-emerald-500 border-emerald-500/20">{t.active}</Badge>
              </div>
              <div className="flex items-center justify-between opacity-50">
                <div>
                  <p className="text-sm font-medium text-white">{t.two_fa}</p>
                  <p className="text-[10px] text-slate-400">{t.coming_soon}</p>
                </div>
                <Badge variant="outline" className="text-slate-600 border-white/10">{t.locked}</Badge>
              </div>
            </CardContent>
          </Card>
        </div>

        <Card className="bg-rose-500/5 border-rose-500/10 shadow-xl">
          <CardHeader>
            <CardTitle className="text-sm font-bold text-rose-500 flex items-center gap-2">
              <Database className="w-4 h-4" />
              {t.danger_zone}
            </CardTitle>
          </CardHeader>
          <CardContent className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-white">{t.clear_data}</p>
              <p className="text-[10px] text-slate-400">{t.clear_data_desc}</p>
            </div>
            <Button 
              variant="destructive" 
              size="sm" 
              className="h-8 text-[10px] font-bold uppercase tracking-widest"
              onClick={onClearData}
            >
              {t.wipe_data}
            </Button>
          </CardContent>
        </Card>

        {/* Discord Webhook Configuration */}
        <Card className="card-glass border-primary/20 bg-primary/5">
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2 text-white">
              <Send className="w-5 h-5 text-primary" />
              {t.webhook_title}
            </CardTitle>
            <CardDescription className="text-slate-400">
              {t.webhook_subtitle}
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <label className="text-xs font-bold text-slate-400 uppercase tracking-widest">{t.webhook_url}</label>
              <div className="flex gap-3">
                <Input 
                  type="text" 
                  placeholder="https://discord.com/api/webhooks/..." 
                  className="bg-black/40 border-white/10 text-white h-11"
                  value={webhookUrl}
                  onChange={(e) => setWebhookUrl(e.target.value)}
                />
                <Button 
                  onClick={handleSaveWebhook}
                  className="btn-gradient h-11 px-6 font-bold"
                >
                  {t.save}
                </Button>
              </div>
            </div>
            
            <div className="pt-4 border-t border-white/5 flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-white">{t.test_connection}</p>
                <p className="text-[10px] text-slate-400">{t.test_connection_desc}</p>
              </div>
              <Button 
                variant="outline" 
                size="sm" 
                className="h-9 bg-white/5 border-white/10 text-xs hover:bg-white/10"
                onClick={handleTestWebhook}
                disabled={!webhookUrl || isTestingWebhook}
              >
                {isTestingWebhook ? t.sending : t.send_test}
              </Button>
            </div>

            {webhookMessage && (
              <div className={`p-3 rounded-lg flex items-center gap-3 text-xs ${
                webhookMessage.type === 'success' ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20' : 'bg-rose-500/10 text-rose-400 border border-rose-500/20'
              }`}>
                {webhookMessage.type === 'success' ? <CheckCircle2 className="w-4 h-4" /> : <AlertCircle className="w-4 h-4" />}
                {webhookMessage.text}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
