import { useState, useEffect } from "react";
import { motion } from "motion/react";
import { 
  ArrowLeft, 
  Activity, 
  Users, 
  Shield, 
  Cpu, 
  Globe,
  Clock,
  Zap,
  Terminal,
  List
} from "lucide-react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Bot, BotCommand } from "@/src/types";

interface BotDetailViewProps {
  bot: Bot;
  onBack: () => void;
  t: any;
}

export function BotDetailView({ bot, onBack, t }: BotDetailViewProps) {
  const [isRestarting, setIsRestarting] = useState(false);
  const [isClearingCache, setIsClearingCache] = useState(false);
  const [memoryHistory, setMemoryHistory] = useState<number[]>([110, 115, 112, 118, 114, 112]);
  const [activeNode, setActiveNode] = useState<string | null>(null);

  // Parse RAM string to number (e.g., "156MB" -> 156)
  const ramValue = parseFloat(bot.ram_usage || "0");
  const cpuValue = bot.cpu_usage || 0;

  useEffect(() => {
    if (ramValue > 0) {
      setMemoryHistory(prev => [...prev.slice(-9), ramValue]);
    }
  }, [ramValue]);

  const defaultSecurityData = [
    "Token stored in secure cloud vault",
    "Privileged intents verified",
    "OAuth2 redirect scope restricted",
    "Anti-spam middleware active",
    "Rate-limit protection enabled"
  ];

  const securityData = bot.security_checklist && bot.security_checklist.length > 0 
    ? bot.security_checklist 
    : defaultSecurityData;

  const defaultCommands: BotCommand[] = [
    { name: "/help", description: "Shows all available commands and bot information.", category: "General" },
    { name: "/ping", description: "Checks the bot's latency and connection status.", category: "Utility" },
    { name: "/stats", description: "Displays detailed bot statistics and resource usage.", category: "Utility" },
    { name: "/settings", description: "Configure bot preferences for your server.", category: "Admin" },
    { name: "/logs", description: "View recent bot activity and error logs.", category: "Admin" }
  ];

  const commands = bot.commands && bot.commands.length > 0 ? bot.commands : defaultCommands;

  const nodes = [
    { id: "eu-1", name: "EU-West-1", traffic: "65%", latency: "12ms", color: "bg-primary" },
    { id: "us-2", name: "US-East-2", traffic: "25%", latency: "85ms", color: "bg-indigo-500" },
    { id: "as-1", name: "AP-South-1", traffic: "10%", latency: "140ms", color: "bg-amber-500" }
  ];

  const handleRestart = () => {
    setIsRestarting(true);
    setTimeout(() => setIsRestarting(false), 3000);
  };

  const handleClearCache = () => {
    setIsClearingCache(true);
    setTimeout(() => setIsClearingCache(false), 1500);
  };

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <Button 
          variant="ghost" 
          className="text-slate-400 hover:text-white gap-2 px-0 hover:bg-transparent"
          onClick={onBack}
        >
          <ArrowLeft className="w-4 h-4" />
          {t.back_to_overview}
        </Button>
        <div className="flex items-center gap-4">
           <div className="hidden sm:flex items-center gap-2 px-3 py-1 bg-emerald-500/10 border border-emerald-500/20 rounded-full">
              <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
              <span className="text-[10px] font-bold text-emerald-500 uppercase tracking-widest">{t.live_monitoring}</span>
           </div>
           <Badge variant="outline" className="bg-white/5 border-white/10 text-slate-400 font-mono text-[10px]">
             v2.4.1-STABLE
           </Badge>
        </div>
      </div>

      <div className="flex flex-col lg:flex-row gap-8 items-start">
        {/* Bot Identity Card */}
        <Card className="w-full lg:w-80 card-glass overflow-hidden lg:sticky lg:top-24 shadow-2xl">
          <div className="h-24 bg-gradient-to-br from-primary/20 to-indigo-500/20 relative">
             <div className="absolute -bottom-10 left-6">
                <Avatar className="w-20 h-20 border-4 border-[#050505] shadow-2xl">
                  <AvatarImage src={bot.avatar || ""} />
                  <AvatarFallback className="bg-primary/20 text-primary text-xl font-bold">
                    {bot.username.substring(0, 2).toUpperCase()}
                  </AvatarFallback>
                </Avatar>
             </div>
          </div>
          <CardContent className="pt-14 pb-6 px-6">
            <div className="flex items-center gap-2 mb-1">
              <h2 className="text-xl font-bold text-white">{bot.username}</h2>
              <Badge variant="outline" className="text-[10px] border-white/10 text-slate-400">#{bot.discriminator}</Badge>
            </div>
            <p className="text-xs text-slate-400 font-mono mb-4">ID: {bot.discord_id || bot.id}</p>
            
            <div className="flex flex-wrap gap-2 mb-6">
              <Badge className={`${
                bot.status === 'online' ? 'bg-emerald-500/10 text-emerald-500 border-emerald-500/20' : 
                bot.status === 'warning' ? 'bg-amber-500/10 text-amber-500 border-amber-500/20' : 
                'bg-rose-500/10 text-rose-500 border-rose-500/20'
              } capitalize`}>
                {bot.status}
              </Badge>
              <Badge variant="outline" className="bg-white/5 border-white/10 text-slate-300">
                {bot.language_detected || "JavaScript"}
              </Badge>
            </div>

            <div className="space-y-4 pt-4 border-t border-white/5">
               <div className="flex items-center justify-between">
                  <span className="text-xs text-slate-400">{t.servers}</span>
                  <span className="text-sm font-bold text-white">{bot.guild_count.toLocaleString()}</span>
               </div>
               <div className="flex items-center justify-between">
                  <span className="text-xs text-slate-400">{t.uptime}</span>
                  <span className="text-sm font-bold text-emerald-400">{(bot.uptime || 99.9).toFixed(2)}%</span>
               </div>
               <div className="flex items-center justify-between">
                  <span className="text-xs text-slate-400">{t.latency}</span>
                  <span className="text-sm font-bold text-white">{(Math.random() * 20 + 10).toFixed(0)}ms</span>
               </div>
               <div className="flex items-center justify-between">
                  <span className="text-xs text-slate-400">{t.shards}</span>
                  <span className="text-sm font-bold text-white">4 {t.active}</span>
               </div>
            </div>

            <div className="grid grid-cols-1 gap-2 mt-6">
              <Button 
                className="btn-gradient w-full h-10 font-bold uppercase tracking-widest text-[10px]"
                onClick={handleRestart}
                disabled={isRestarting}
              >
                {isRestarting ? <Zap className="w-3 h-3 animate-spin mr-2" /> : null}
                {isRestarting ? t.restarting : t.restart_instance}
              </Button>
              <Button 
                variant="outline" 
                className="w-full h-10 bg-white/5 border-white/10 text-slate-400 hover:text-white hover:bg-white/10 font-bold uppercase tracking-widest text-[10px]"
                onClick={handleClearCache}
                disabled={isClearingCache}
              >
                {isClearingCache ? t.clearing : t.clear_cache}
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Main Insights & Tabs */}
        <div className="flex-1 space-y-6 w-full">
          <Tabs defaultValue="insights" className="w-full">
            <TabsList className="bg-black/40 border border-white/10 p-1 mb-6">
              <TabsTrigger value="insights" className="text-xs data-[state=active]:bg-white/10 gap-2">
                <Activity className="w-3 h-3" />
                {t.insights}
              </TabsTrigger>
              <TabsTrigger value="commands" className="text-xs data-[state=active]:bg-white/10 gap-2">
                <Terminal className="w-3 h-3" />
                {t.commands}
              </TabsTrigger>
            </TabsList>

            <TabsContent value="insights" className="space-y-6 mt-0">
              <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-4">
                <Card className="card-glass shadow-xl">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium text-slate-300 flex items-center gap-2">
                      <Activity className="w-4 h-4 text-primary" />
                      {t.resource_usage}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-end justify-between">
                      <div className="flex items-end gap-2">
                        <span className="text-2xl font-bold text-white">{bot.ram_usage || "0MB"}</span>
                        <span className="text-xs text-slate-400 mb-1">{t.ram}</span>
                      </div>
                      <div className="flex gap-0.5 items-end h-8">
                        {memoryHistory.map((h, i) => (
                          <div 
                            key={i} 
                            className="w-1 bg-primary/40 rounded-t-sm" 
                            style={{ height: `${Math.min(100, (h / 512) * 100)}%` }} 
                          />
                        ))}
                      </div>
                    </div>
                    <div className="mt-4 h-1.5 w-full bg-white/5 rounded-full overflow-hidden">
                       <motion.div 
                         className="h-full bg-primary shadow-[0_0_10px_rgba(59,130,246,0.5)]" 
                         animate={{ width: `${Math.min(100, (ramValue / 512) * 100)}%` }}
                         transition={{ duration: 1 }}
                       />
                    </div>
                  </CardContent>
                </Card>

                <Card className="card-glass shadow-xl">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium text-slate-300 flex items-center gap-2">
                      <Cpu className="w-4 h-4 text-amber-500" />
                      {t.cpu_load}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-end gap-2">
                      <span className="text-2xl font-bold text-white">{cpuValue.toFixed(2)}%</span>
                      <span className="text-xs text-slate-400 mb-1">Avg</span>
                    </div>
                    <div className="mt-4 h-1.5 w-full bg-white/5 rounded-full overflow-hidden">
                       <motion.div 
                         className="h-full bg-amber-500 shadow-[0_0_10px_rgba(245,158,11,0.5)]" 
                         animate={{ width: `${cpuValue}%` }}
                         transition={{ duration: 1 }}
                       />
                    </div>
                  </CardContent>
                </Card>

                <Card className="card-glass shadow-xl sm:col-span-2 xl:col-span-1">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium text-slate-300 flex items-center gap-2">
                      <Users className="w-4 h-4 text-indigo-400" />
                      {t.engagement}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-end gap-2">
                      <span className="text-2xl font-bold text-white">{(bot.guild_count * 150).toLocaleString()}</span>
                      <span className="text-xs text-slate-400 mb-1">{t.total_users}</span>
                    </div>
                    <div className="mt-4 flex items-center justify-between text-[10px] font-bold uppercase tracking-widest text-slate-500">
                      <span>{t.commands}: {(bot.guild_count * 42).toLocaleString()}</span>
                      <span className="text-indigo-400">Live</span>
                    </div>
                  </CardContent>
                </Card>
              </div>

              <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
                <Card className="card-glass shadow-xl">
                  <CardHeader>
                    <CardTitle className="text-lg flex items-center gap-2 text-white">
                      <Shield className="w-5 h-5 text-emerald-500" />
                      {t.security_compliance}
                    </CardTitle>
                    <CardDescription className="text-slate-400">{t.monitoring_desc}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {securityData.map((item, i) => (
                        <div key={i} className="flex items-start gap-3 p-3 bg-white/5 rounded-xl border border-white/5 group hover:bg-white/10 transition-colors">
                          <div className="w-5 h-5 rounded-full bg-emerald-500/20 flex items-center justify-center shrink-0 mt-0.5 group-hover:bg-emerald-500 group-hover:text-white transition-all">
                            <Zap className="w-3 h-3 text-emerald-500 group-hover:text-white" />
                          </div>
                          <p className="text-sm text-slate-200">{item}</p>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>

                <Card className="card-glass shadow-xl">
                  <CardHeader>
                    <CardTitle className="text-lg flex items-center gap-2 text-white">
                      <Globe className="w-5 h-5 text-indigo-500" />
                      {t.global_distribution}
                    </CardTitle>
                    <CardDescription className="text-slate-400">{t.distribution_desc || "Traffic distribution across global clusters."}</CardDescription>
                  </CardHeader>
                  <CardContent>
                     <div className="h-48 bg-white/5 rounded-2xl flex flex-col items-center justify-center border border-dashed border-white/10 relative overflow-hidden group cursor-crosshair">
                        <div className="absolute inset-0 bg-primary/5 opacity-0 group-hover:opacity-100 transition-opacity" />
                        
                        {/* Simulated Map Nodes */}
                        <div className="absolute top-1/4 left-1/3 w-3 h-3 bg-primary rounded-full animate-ping opacity-50" />
                        <div className="absolute top-1/4 left-1/3 w-2 h-2 bg-primary rounded-full shadow-[0_0_10px_rgba(59,130,246,1)]" />
                        
                        <div className="absolute top-1/2 right-1/4 w-3 h-3 bg-indigo-500 rounded-full animate-ping opacity-50" />
                        <div className="absolute top-1/2 right-1/4 w-2 h-2 bg-indigo-500 rounded-full shadow-[0_0_10px_rgba(99,102,241,1)]" />

                        <Globe className="w-12 h-12 text-slate-700 mb-2 group-hover:text-primary transition-colors group-hover:animate-spin-slow" />
                        <p className="text-slate-500 text-sm relative z-10">Interactive Cluster Map</p>
                        <p className="text-[10px] text-slate-600 mt-1 uppercase tracking-widest relative z-10">{t.stable}</p>
                     </div>
                     <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mt-6">
                        {nodes.map(node => (
                          <div 
                            key={node.id} 
                            className={cn(
                              "p-3 rounded-xl border transition-all cursor-pointer",
                              activeNode === node.id ? "bg-white/10 border-primary/50" : "bg-white/5 border-white/5 hover:bg-white/10"
                            )}
                            onClick={() => setActiveNode(node.id === activeNode ? null : node.id)}
                          >
                             <div className="flex items-center gap-2 mb-1">
                                <div className={cn("w-2 h-2 rounded-full", node.color)} />
                                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">{node.name}</span>
                             </div>
                             <div className="flex items-center justify-between">
                                <p className="text-sm font-bold text-white">{node.traffic}</p>
                                <p className="text-[10px] text-slate-500 font-mono">{node.latency}</p>
                             </div>
                          </div>
                        ))}
                     </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="commands" className="mt-0">
              <Card className="card-glass border-white/5 shadow-2xl overflow-hidden">
                <CardHeader className="border-b border-white/5 bg-white/[0.02]">
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle className="text-lg text-white flex items-center gap-2">
                        <Terminal className="w-5 h-5 text-primary" />
                        {t.command_registry}
                      </CardTitle>
                      <CardDescription className="text-slate-400">{t.manager_desc}</CardDescription>
                    </div>
                    <Badge variant="outline" className="bg-primary/10 text-primary border-primary/20">
                      {commands.length} {t.commands}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent className="p-0">
                  <div className="divide-y divide-white/5">
                    {commands.map((cmd, i) => (
                      <motion.div 
                        key={i}
                        initial={{ opacity: 0, x: -10 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: i * 0.05 }}
                        className="p-4 hover:bg-white/[0.03] transition-colors group"
                      >
                        <div className="flex items-start justify-between gap-4">
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-1">
                              <span className="text-sm font-bold text-primary font-mono">{cmd.name}</span>
                              {cmd.category && (
                                <Badge variant="outline" className="text-[9px] h-4 px-1.5 bg-white/5 border-white/10 text-slate-500 uppercase tracking-tighter">
                                  {cmd.category}
                                </Badge>
                              )}
                            </div>
                            <p className="text-xs text-slate-400 leading-relaxed">{cmd.description}</p>
                          </div>
                          <Button variant="ghost" size="icon" className="h-8 w-8 text-slate-600 group-hover:text-white opacity-0 group-hover:opacity-100 transition-all">
                            <ArrowLeft className="w-4 h-4 rotate-180" />
                          </Button>
                        </div>
                      </motion.div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
}
