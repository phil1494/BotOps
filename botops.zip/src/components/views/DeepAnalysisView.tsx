import { useState, useEffect, useCallback } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  Terminal, 
  Zap, 
  Search,
  RefreshCw,
  Copy,
  Send,
  AlertOctagon,
  ChevronRight,
  ArrowRight,
  Activity,
  CheckCircle2,
  AlertTriangle,
  ShieldAlert,
  Cpu,
  HardDrive,
  Clock,
  ChevronDown,
  LayoutDashboard,
  FileSearch
} from "lucide-react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { BotAnalysis } from "@/src/types";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";

const SAMPLE_LOGS: any[] = [];

interface DeepAnalysisViewProps {
  history: BotAnalysis[];
  totalAnalyses: number;
  onAnalyze: (log: string) => Promise<BotAnalysis>;
  onClearHistory: () => void;
  scanForTokens: (input: string) => boolean;
  copyToClipboard: (text: string) => void;
  t: any;
}

export function DeepAnalysisView({ 
  history, 
  totalAnalyses,
  onAnalyze, 
  onClearHistory, 
  scanForTokens, 
  copyToClipboard,
  t
}: DeepAnalysisViewProps) {
  const [logInput, setLogInput] = useState("");
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysis, setAnalysis] = useState<BotAnalysis | null>(null);
  const [hasTokenLeak, setHasTokenLeak] = useState(false);
  const [webhookActive, setWebhookActive] = useState(false);
  const [uptime, setUptime] = useState(0);
  const [showTemplates, setShowTemplates] = useState(false);

  // Uptime Counter
  useEffect(() => {
    const timer = setInterval(() => setUptime(prev => prev + 1), 1000);
    return () => clearInterval(timer);
  }, []);

  const formatUptime = (seconds: number) => {
    const h = Math.floor(seconds / 3600);
    const m = Math.floor((seconds % 3600) / 60);
    const s = seconds % 60;
    return `${h > 0 ? h + 'h ' : ''}${m}m ${s}s`;
  };

  const QUICK_TEMPLATES = [
    { 
      name: "Permission Error", 
      content: "discord.errors.Forbidden: 403 Forbidden (error code: 50013): Missing Permissions\n    at /app/node_modules/discord.js/src/rest/RequestHandler.js:350:13" 
    },
    { 
      name: "Rate Limit", 
      content: "discord.errors.HTTPException: 429 Too Many Requests (error code: 0): You are being rate limited.\n    at /app/main.py:120: await channel.send(msg)" 
    },
    { 
      name: "Token Invalid", 
      content: "discord.errors.LoginFailure: Improper token has been passed.\n    at discord.client.login(token)\n    at /app/bot.py:45" 
    }
  ];

  // Check Webhook Status
  useEffect(() => {
    const url = localStorage.getItem("botops_webhook_url");
    setWebhookActive(!!url);
  }, []);

  // Token Detection
  useEffect(() => {
    if (logInput.trim().length > 0) {
      setHasTokenLeak(scanForTokens(logInput));
    } else {
      setHasTokenLeak(false);
    }
  }, [logInput, scanForTokens]);

  const handleAnalyze = async () => {
    if (!logInput.trim()) return;
    setIsAnalyzing(true);
    try {
      const result = await onAnalyze(logInput);
      setAnalysis(result);

      // Automatic Webhook Notification
      const webhookUrl = localStorage.getItem("botops_webhook_url");
      if (webhookUrl && result) {
        fetch(webhookUrl, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            embeds: [{
              title: `🔍 BotOps Analyse: ${result.bot_status.toUpperCase()}`,
              color: result.bot_status === 'online' ? 0x10b981 : result.bot_status === 'warning' ? 0xf59e0b : 0xef4444,
              fields: [
                { name: "Health Score", value: `${result.health_score}%`, inline: true },
                { name: "Status", value: result.bot_status.toUpperCase(), inline: true },
                { name: t.analysis, value: result.analysis },
                { name: t.fix, value: result.fix_steps.map((s, i) => `${i + 1}. ${s}`).join('\n') }
              ],
              footer: { text: "Automatische Analyse von BotOps Intelligence" },
              timestamp: new Date().toISOString()
            }]
          })
        }).catch(err => console.error("Webhook Error:", err));
      }
    } catch (error) {
      console.error(error);
    } finally {
      setIsAnalyzing(false);
    }
  };

  const exportToDiscord = () => {
    if (!analysis) return;
    const embed = `
**BotOps Analysis Report**
--------------------------
**Status:** ${analysis.bot_status.toUpperCase()}
**Health Score:** ${analysis.health_score}%
**Analysis:** ${analysis.analysis}

**Fix Steps:**
${analysis.fix_steps.map((s, i) => `${i + 1}. ${s}`).join('\n')}

${analysis.suggested_fix_code ? `**Suggested Fix:**\n\`\`\`py\n${analysis.suggested_fix_code}\n\`\`\`` : ''}
--------------------------
*Generated by BotOps Intelligence*
    `.trim();
    copyToClipboard(embed);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "online": return "text-emerald-400 bg-emerald-400/10 border-emerald-400/20";
      case "warning": return "text-amber-400 bg-amber-400/10 border-amber-400/20";
      case "error": return "text-rose-400 bg-rose-400/10 border-rose-400/20";
      default: return "text-slate-400 bg-slate-400/10 border-slate-400/20";
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "online": return <CheckCircle2 className="w-4 h-4" />;
      case "warning": return <AlertTriangle className="w-4 h-4" />;
      case "error": return <ShieldAlert className="w-4 h-4" />;
      default: return <Activity className="w-4 h-4" />;
    }
  };

  const handleCopyAllLogs = () => {
    if (history.length === 0) return;
    const allLogs = history.map((item, index) => {
      return `[${index + 1}] ${item.timestamp || 'N/A'}\nStatus: ${item.bot_status}\nScore: ${item.health_score}%\nAnalysis: ${item.analysis}\n-------------------`;
    }).join('\n\n');
    copyToClipboard(allLogs);
  };

  const HeaderStats = () => (
    <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 mb-6">
      {[
        { 
          label: t.total_analyses || "Total Analyses", 
          value: totalAnalyses, 
          icon: Activity, 
          color: "text-primary", 
          bg: "bg-primary/5",
          border: "border-primary/10"
        },
        { 
          label: t.webhook_status || "Webhook Status", 
          value: webhookActive ? (t.active || 'Active') : (t.inactive || 'Inactive'), 
          icon: Send, 
          color: webhookActive ? "text-emerald-400" : "text-slate-400", 
          bg: webhookActive ? "bg-emerald-400/5" : "bg-slate-400/5",
          border: webhookActive ? "border-emerald-400/10" : "border-slate-400/10",
          dot: webhookActive
        },
        { 
          label: t.system_health || "System Health", 
          value: "99.9%", 
          icon: Zap, 
          color: "text-amber-400", 
          bg: "bg-amber-400/5",
          border: "border-amber-400/10"
        }
      ].map((stat, i) => (
        <Card key={i} className={cn("card-glass bg-white/[0.01] overflow-hidden transition-all duration-300 hover:bg-white/[0.03]", stat.border)}>
          <CardContent className="p-5 flex items-center gap-4">
            <div className={cn("w-10 h-10 rounded-xl flex items-center justify-center border", stat.bg, stat.border)}>
              <stat.icon className={cn("w-5 h-5", stat.color)} />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-[10px] font-bold text-slate-500 uppercase tracking-[0.15em] mb-0.5">{stat.label}</p>
              <div className="flex items-center gap-2">
                <p className="text-lg font-bold text-white tracking-tight">{stat.value}</p>
                {stat.dot && <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse shadow-[0_0_8px_rgba(16,185,129,0.5)]" />}
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );

  return (
    <div className="max-w-7xl mx-auto pb-12">
      <div className="space-y-6">
        <HeaderStats />

      {/* Mobile View: Tabs for History vs Analysis */}
      <div className="lg:hidden">
        <Tabs defaultValue="analysis" className="w-full">
          <TabsList className="grid w-full grid-cols-2 bg-black/40 p-1 mb-6">
            <TabsTrigger value="history" className="text-xs">{t.timeline}</TabsTrigger>
            <TabsTrigger value="analysis" className="text-xs">{t.analysis}</TabsTrigger>
          </TabsList>
          
          <TabsContent value="history" className="space-y-6">
            <TimelineSection 
              history={history} 
              analysis={analysis} 
              setAnalysis={setAnalysis} 
              setLogInput={setLogInput} 
              onClearHistory={onClearHistory}
              handleCopyAllLogs={handleCopyAllLogs}
              getStatusColor={getStatusColor}
              getStatusIcon={getStatusIcon}
              t={t}
            />
          </TabsContent>
          
          <TabsContent value="analysis" className="space-y-6">
            <AnalysisInputSection 
              isAnalyzing={isAnalyzing}
              hasTokenLeak={hasTokenLeak}
              logInput={logInput}
              setLogInput={setLogInput}
              handleAnalyze={handleAnalyze}
              QUICK_TEMPLATES={QUICK_TEMPLATES}
              history={history}
              setAnalysis={setAnalysis}
              t={t}
            />
            <AnalysisResultSection 
              analysis={analysis}
              isAnalyzing={isAnalyzing}
              getStatusColor={getStatusColor}
              getStatusIcon={getStatusIcon}
              exportToDiscord={exportToDiscord}
              copyToClipboard={copyToClipboard}
              setAnalysis={setAnalysis}
              t={t}
            />
          </TabsContent>
        </Tabs>
      </div>

      {/* Desktop Layout: 30/70 Split */}
      <div className="hidden lg:grid lg:grid-cols-12 gap-6 items-start">
        {/* Left Column: Timeline (30%) */}
        <div className="lg:col-span-4 lg:xl:col-span-3">
          <TimelineSection 
            history={history} 
            analysis={analysis} 
            setAnalysis={setAnalysis} 
            setLogInput={setLogInput} 
            onClearHistory={onClearHistory}
            handleCopyAllLogs={handleCopyAllLogs}
            getStatusColor={getStatusColor}
            getStatusIcon={getStatusIcon}
            t={t}
          />
        </div>

        {/* Right Column: Analysis (70%) */}
        <div className="lg:col-span-8 lg:xl:col-span-9 space-y-6">
          <AnalysisInputSection 
            isAnalyzing={isAnalyzing}
            hasTokenLeak={hasTokenLeak}
            logInput={logInput}
            setLogInput={setLogInput}
            handleAnalyze={handleAnalyze}
            QUICK_TEMPLATES={QUICK_TEMPLATES}
            history={history}
            setAnalysis={setAnalysis}
            t={t}
          />
          <AnalysisResultSection 
            analysis={analysis}
            isAnalyzing={isAnalyzing}
            getStatusColor={getStatusColor}
            getStatusIcon={getStatusIcon}
            exportToDiscord={exportToDiscord}
            copyToClipboard={copyToClipboard}
            setAnalysis={setAnalysis}
            t={t}
          />
        </div>
      </div>
    </div>
  </div>
);
}

// Sub-components for cleaner responsive management
function TimelineSection({ history, analysis, setAnalysis, setLogInput, onClearHistory, handleCopyAllLogs, getStatusColor, getStatusIcon, t }: any) {
  return (
    <Card className="card-glass flex flex-col h-full bg-white/[0.01] border-white/5">
      <CardHeader className="p-4 flex flex-row items-center justify-between space-y-0 border-b border-white/5">
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 rounded-lg bg-white/5 flex items-center justify-center">
            <Clock className="w-3.5 h-3.5 text-slate-400" />
          </div>
          <CardTitle className="text-xs font-bold uppercase tracking-[0.15em] text-slate-400">
            {t.timeline}
          </CardTitle>
        </div>
        <div className="flex items-center gap-1">
          <Button variant="ghost" size="sm" onClick={handleCopyAllLogs} className="h-7 w-7 p-0 text-slate-500 hover:text-primary hover:bg-primary/10" disabled={history.length === 0}>
            <Copy className="w-3.5 h-3.5" />
          </Button>
          <Button variant="ghost" size="sm" onClick={onClearHistory} className="h-7 px-2 text-[10px] font-bold text-slate-500 hover:text-rose-500 hover:bg-rose-500/10 uppercase tracking-wider">{t.clear || "Clear"}</Button>
        </div>
      </CardHeader>
      <CardContent className="p-0 flex-1 overflow-hidden">
        <ScrollArea className="h-auto max-h-[600px]">
          <div className="p-4 space-y-3">
            {history.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-12 text-center">
                <div className="w-12 h-12 rounded-full bg-white/[0.02] flex items-center justify-center mb-3 border border-white/5">
                  <Activity className="w-5 h-5 text-slate-600" />
                </div>
                <p className="text-[11px] text-slate-500 font-medium italic">{t.no_history}</p>
              </div>
            ) : (
              history.map((item: any, i: number) => (
                <motion.div 
                  key={i} 
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: i * 0.05 }}
                  className={cn(
                    "p-3 rounded-xl border transition-all duration-300 flex items-center justify-between group cursor-pointer relative overflow-hidden",
                    analysis === item 
                      ? "bg-primary/10 border-primary/30 shadow-[0_0_15px_rgba(59,130,246,0.1)]" 
                      : "bg-white/[0.02] border-white/5 hover:bg-white/[0.05] hover:border-white/10"
                  )}
                  onClick={() => {
                    setAnalysis(item);
                    setLogInput("");
                  }}
                >
                  {analysis === item && (
                    <div className="absolute left-0 top-0 bottom-0 w-1 bg-primary" />
                  )}
                  <div className="flex items-center gap-3">
                    <div className={cn(
                      "w-8 h-8 rounded-lg flex items-center justify-center shrink-0 border",
                      getStatusColor(item.bot_status).replace('text-', 'border-').replace('bg-', 'bg-opacity-20 bg-')
                    )}>
                      <Zap className={cn("w-4 h-4", getStatusColor(item.bot_status).split(' ')[0])} />
                    </div>
                    <div className="min-w-0">
                      <p className={cn(
                        "text-[11px] font-bold truncate max-w-[140px] tracking-tight",
                        analysis === item ? "text-primary" : "text-white"
                      )}>{item.analysis}</p>
                      <div className="flex items-center gap-2 mt-0.5">
                        <span className="text-[9px] text-slate-500 font-mono">{item.timestamp || new Date().toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}</span>
                        <div className="w-1 h-1 rounded-full bg-slate-700" />
                        <span className={cn("text-[9px] font-bold uppercase", getStatusColor(item.bot_status).split(' ')[0])}>{item.bot_status}</span>
                      </div>
                    </div>
                  </div>
                  <ChevronRight className={cn(
                    "w-3.5 h-3.5 transition-all duration-300",
                    analysis === item ? "text-primary translate-x-0" : "text-slate-700 group-hover:text-slate-400 group-hover:translate-x-0.5"
                  )} />
                </motion.div>
              ))
            )}
          </div>
        </ScrollArea>
      </CardContent>
    </Card>
  );
}

function AnalysisInputSection({ isAnalyzing, hasTokenLeak, logInput, setLogInput, handleAnalyze, QUICK_TEMPLATES, history, setAnalysis, t }: any) {
  return (
    <Card className="card-glass shadow-2xl overflow-hidden group border-white/5 bg-white/[0.01]">
      <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
      <CardHeader className="relative p-4 border-b border-white/5">
        <div className="flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center border border-primary/20">
              <Terminal className="w-4 h-4 text-primary" />
            </div>
            <div>
              <CardTitle className="text-sm font-bold uppercase tracking-[0.15em] text-white">{t.log_analyzer}</CardTitle>
              <p className="text-[10px] text-slate-500 font-medium mt-0.5">{t.ai_diagnostics}</p>
            </div>
          </div>
          
          <Dialog>
            <DialogTrigger 
              render={
                <Button variant="outline" size="sm" className="h-8 text-[10px] font-bold uppercase tracking-wider bg-white/5 border-white/10 hover:bg-primary/20 hover:border-primary/30 gap-2 transition-all">
                  Templates
                  <ChevronDown className="w-3.5 h-3.5" />
                </Button>
              }
            />
            <DialogContent className="bg-[#0a0a0c] border-white/10 text-white max-w-md">
              <DialogHeader>
                <DialogTitle className="text-lg font-bold tracking-tight">{t.templates}</DialogTitle>
                <CardDescription className="text-slate-500">{t.template_desc}</CardDescription>
              </DialogHeader>
              <div className="grid grid-cols-1 gap-3 pt-4">
                {QUICK_TEMPLATES.map((tmpl: any, i: number) => (
                  <Button
                    key={i}
                    variant="outline"
                    className="justify-start h-auto py-4 px-5 bg-white/[0.02] border-white/5 hover:bg-primary/10 hover:border-primary/30 hover:shadow-[0_0_15px_rgba(59,130,246,0.1)] text-left transition-all group"
                    onClick={() => {
                      setLogInput(tmpl.content);
                    }}
                  >
                    <div className="w-full">
                      <div className="flex items-center justify-between mb-1">
                        <p className="text-xs font-bold text-primary uppercase tracking-widest">{tmpl.name}</p>
                        <ArrowRight className="w-3 h-3 text-slate-700 group-hover:text-primary group-hover:translate-x-1 transition-all" />
                      </div>
                      <p className="text-[10px] text-slate-500 line-clamp-1 font-mono">{tmpl.content}</p>
                    </div>
                  </Button>
                ))}
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </CardHeader>
      <CardContent className="p-4 pt-4 space-y-4 relative">
        <AnimatePresence>
          {hasTokenLeak && (
            <motion.div 
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: 'auto', opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              className="overflow-hidden"
            >
              <div className="bg-rose-500/10 border border-rose-500/30 rounded-xl p-4 flex items-start gap-4 mb-2 shadow-[0_0_20px_rgba(244,63,94,0.1)]">
                <div className="w-8 h-8 rounded-lg bg-rose-500/20 flex items-center justify-center shrink-0">
                  <AlertOctagon className="w-5 h-5 text-rose-500" />
                </div>
                <div>
                  <p className="text-xs font-bold text-rose-500 uppercase tracking-widest">{t.security_warning}</p>
                  <p className="text-[11px] text-rose-400/80 leading-relaxed mt-1">{t.token_leak_desc}</p>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        <div className="relative group/editor">
          {isAnalyzing && <div className="scanning-line z-10" />}
          
          {/* Editor Decoration */}
          <div className="absolute left-0 top-0 bottom-0 w-10 bg-black/40 border-r border-white/5 rounded-l-xl flex flex-col items-center py-4 gap-1 pointer-events-none select-none">
            {[...Array(12)].map((_, i) => (
              <span key={i} className="text-[9px] font-mono text-slate-700">{i + 1}</span>
            ))}
          </div>

          <Textarea 
            placeholder={t.log_placeholder}
            spellCheck={false}
            className={cn(
              "min-h-[300px] bg-[#08080a] text-slate-300 border-white/5 pl-14 pr-4 py-4 focus:border-primary/30 focus-visible:ring-0 focus-visible:ring-offset-0 outline-none transition-all font-mono text-[13px] leading-relaxed resize-none scrollbar-thin scrollbar-thumb-white/10 rounded-xl shadow-inner overflow-y-auto",
              isAnalyzing && "opacity-50"
            )}
            value={logInput}
            onChange={(e) => setLogInput(e.target.value)}
          />
        </div>

        <div className="flex items-center justify-between gap-4">
          <div className="flex-1">
            {history.length > 0 && (
              <div className="flex items-center gap-2 overflow-x-auto scrollbar-none py-1">
                <span className="text-[9px] font-bold text-slate-600 uppercase tracking-widest shrink-0">Recent:</span>
                {history.slice(0, 2).map((item: any, i: number) => (
                  <button
                    key={i}
                    onClick={() => setAnalysis(item)}
                    className="px-3 py-1.5 rounded-lg bg-white/[0.02] border border-white/5 hover:bg-white/[0.05] hover:border-primary/30 transition-all flex items-center gap-2 shrink-0 group"
                  >
                    <div className={cn("w-1.5 h-1.5 rounded-full", 
                      item.bot_status === 'online' ? 'bg-emerald-500' : 
                      item.bot_status === 'warning' ? 'bg-amber-500' : 'bg-rose-500'
                    )} />
                    <span className="text-[9px] text-slate-400 font-medium truncate max-w-[80px]">{item.analysis}</span>
                  </button>
                ))}
              </div>
            )}
          </div>

          <Button 
            className="btn-gradient px-8 h-11 text-xs font-bold uppercase tracking-[0.2em] transition-all group shadow-lg shadow-primary/20 hover:shadow-primary/40"
            onClick={handleAnalyze}
            disabled={isAnalyzing || !logInput}
          >
            {isAnalyzing ? (
              <RefreshCw className="w-4 h-4 animate-spin mr-2" />
            ) : (
              <Zap className="w-4 h-4 mr-2 fill-current" />
            )}
            {isAnalyzing ? t.analyzing : t.analyze_logs}
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}

function AnalysisResultSection({ analysis, isAnalyzing, getStatusColor, getStatusIcon, exportToDiscord, copyToClipboard, setAnalysis, t }: any) {
  if (!analysis && !isAnalyzing) return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="h-full min-h-[300px] flex flex-col items-center justify-center text-center p-8 border-2 border-dashed border-white/5 rounded-3xl bg-white/[0.01]"
    >
      <div className="w-16 h-16 bg-white/5 rounded-full flex items-center justify-center mb-4">
        <Search className="w-8 h-8 text-slate-600" />
      </div>
      <h3 className="text-lg font-semibold text-white mb-2">{t.ready_for_analysis}</h3>
      <p className="text-slate-400 text-sm max-w-xs">
        {t.ready_desc}
      </p>
    </motion.div>
  );

  if (isAnalyzing) return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="h-full min-h-[300px] flex flex-col items-center justify-center p-8"
    >
      <div className="relative w-24 h-24 mb-6">
        <div className="absolute inset-0 rounded-full border-4 border-primary/20" />
        <div className="absolute inset-0 rounded-full border-4 border-primary border-t-transparent animate-spin" />
        <div className="absolute inset-0 flex items-center justify-center">
          <Zap className="w-10 h-10 text-primary animate-pulse" />
        </div>
      </div>
      <h3 className="text-lg font-bold text-white mb-1">{t.ai_working}</h3>
      <p className="text-xs text-slate-500 animate-pulse">{t.analyzing_tracebacks}</p>
    </motion.div>
  );

  return (
    <motion.div 
      initial={{ opacity: 0, scale: 0.98 }}
      animate={{ opacity: 1, scale: 1 }}
      className="space-y-6"
    >
      <div className="flex items-center justify-between">
        <h3 className="text-base font-bold text-white flex items-center gap-2 uppercase tracking-widest opacity-70">
          <Activity className="w-4 h-4 text-primary" />
          {t.analysis_results}
        </h3>
        <Button variant="ghost" size="sm" className="text-[10px] text-slate-400 gap-1" onClick={() => setAnalysis(null)}>
          <RefreshCw className="w-3 h-3" />
          {t.new}
        </Button>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <Card className="card-glass p-4">
          <div className="flex items-center justify-between mb-2">
            <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">{t.status}</span>
            <Badge className={cn("text-[9px] h-4 px-2", getStatusColor(analysis.bot_status))}>{analysis.bot_status}</Badge>
          </div>
          <p className="text-sm font-bold text-white">{analysis.bot_status === 'online' ? t.healthy : t.critical}</p>
        </Card>
        <Card className="card-glass p-4">
          <div className="flex items-center justify-between mb-2">
            <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">{t.health}</span>
            <span className="text-[10px] font-bold text-emerald-400">{analysis.health_score}%</span>
          </div>
          <Progress value={analysis.health_score} className="h-1.5 bg-white/5" />
        </Card>
        <Card className="card-glass p-4">
          <div className="flex items-center justify-between mb-1.5">
            <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">{t.insight}</span>
            <Zap className="w-3 h-3 text-primary" />
          </div>
          <p className="text-[11px] text-slate-300 italic line-clamp-2">"{analysis.stats_insight}"</p>
        </Card>
      </div>

      <Card className="card-glass overflow-hidden">
        <Tabs defaultValue="analysis" className="w-full">
          <div className="px-4 py-3 border-b border-white/5 flex items-center justify-between">
            <TabsList className="bg-black/40 h-8 p-0.5">
              <TabsTrigger value="analysis" className="text-[10px] px-3">{t.analysis}</TabsTrigger>
              <TabsTrigger value="steps" className="text-[10px] px-3">{t.fix}</TabsTrigger>
            </TabsList>
            <Button variant="outline" size="sm" className="h-7 text-[9px] gap-1.5" onClick={exportToDiscord}>
              <Send className="w-2.5 h-2.5" />
              Discord
            </Button>
          </div>
          <CardContent className="p-4">
            <TabsContent value="analysis" className="m-0">
              <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">{analysis.analysis}</p>
            </TabsContent>
            <TabsContent value="steps" className="m-0 space-y-4">
              <div className="space-y-2">
                {analysis.fix_steps.map((step: string, i: number) => (
                  <div key={i} className="flex gap-3">
                    <div className="w-4 h-4 rounded-full bg-primary/10 flex items-center justify-center text-[8px] font-bold text-primary shrink-0 mt-0.5">{i + 1}</div>
                    <p className="text-[11px] text-slate-300">{step}</p>
                  </div>
                ))}
              </div>
              {analysis.suggested_fix_code && (
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-[9px] font-bold text-primary uppercase">Code Fix</span>
                    <Button variant="ghost" size="sm" className="h-6 text-[8px] gap-1" onClick={() => copyToClipboard(analysis.suggested_fix_code)}>
                      <Copy className="w-2.5 h-2.5" /> Copy
                    </Button>
                  </div>
                  <pre className="p-3 bg-black/60 rounded-lg border border-white/10 font-mono text-[10px] text-emerald-400 overflow-x-auto">
                    <code>{analysis.suggested_fix_code}</code>
                  </pre>
                </div>
              )}
            </TabsContent>
          </CardContent>
        </Tabs>
      </Card>
    </motion.div>
  );
}
