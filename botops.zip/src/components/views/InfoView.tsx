import { useState, useMemo } from "react";
import { motion } from "motion/react";
import { 
  Info, 
  Zap, 
  ShieldCheck, 
  Terminal, 
  Bot as BotIcon, 
  Globe, 
  Cpu,
  ArrowRight,
  CheckCircle2,
  LayoutDashboard,
  Activity,
  Code,
  Copy,
  Check,
  Server,
  Download,
  FileCode
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

interface InfoViewProps {
  t: any;
  onGoToDashboard: () => void;
  bots: any[];
  userId?: string;
  onDownload?: () => void;
}

export function InfoView({ t, onGoToDashboard, bots, userId, onDownload }: InfoViewProps) {
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [selectedBotId, setSelectedBotId] = useState<string>(bots[0]?.id || "");

  const selectedBot = useMemo(() => 
    bots.find(b => b.id === selectedBotId) || bots[0], 
  [bots, selectedBotId]);

  const trackingKey = selectedBot?.tracking_key || "YOUR_TRACKING_KEY";
  const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || "https://YOUR-PROJECT.supabase.co";
  const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY || "YOUR_ANON_KEY";
  const endpoint = `${supabaseUrl}/rest/v1/cluster_stats`;

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const pythonCode = `import requests
import json

def update_bot_stats():
    # Supabase REST Endpoint
    url = "${endpoint}"
    
    headers = {
        "apikey": "${supabaseAnonKey}",
        "Authorization": "Bearer ${supabaseAnonKey}",
        "Content-Type": "application/json",
        "Prefer": "resolution=merge-duplicates"
    }
    
    payload = {
        "id": "${trackingKey}",
        "user_id": "${userId || 'YOUR_USER_ID'}",
        "name": "${selectedBot?.name || selectedBot?.username || 'Optional Name'}",
        "cpu_usage": 12.5,
        "ram_usage": "156MB",
        "status": "online",
        "guild_count": 150
    }
    
    try:
        # Using upsert via POST + Prefer header
        response = requests.post(url, headers=headers, json=payload)
        print(f"Status: {response.status_code}")
    except Exception as e:
        print(f"Error: {e}")`;

  const jsCode = `const axios = require('axios');

async function pushMetrics() {
  const url = "${endpoint}";
  
  const headers = {
    "apikey": "${supabaseAnonKey}",
    "Authorization": "Bearer ${supabaseAnonKey}",
    "Content-Type": "application/json",
    "Prefer": "resolution=merge-duplicates"
  };

  const data = {
    id: "${trackingKey}",
    user_id: "${userId || 'YOUR_USER_ID'}",
    name: "${selectedBot?.name || selectedBot?.username || 'Optional Name'}",
    cpu_usage: 8.2,
    ram_usage: "210MB",
    status: "online",
    guild_count: 420
  };

  try {
    const res = await axios.post(url, data, { headers });
    console.log(\`Metrics pushed: \${res.status}\`);
  } catch (err) {
    console.error(err);
  }
}`;

  const starterKitCode = `import aiohttp
import asyncio
import psutil
import os

class BotOpsConnector:
    """
    BotOps Intelligence Asynchronous Connector
    Optimized for discord.py and nextcord.
    """
    def __init__(self, bot, tracking_key, user_id, supabase_url, anon_key):
        self.bot = bot
        self.tracking_key = tracking_key
        self.user_id = user_id
        self.url = f"{supabase_url}/rest/v1/cluster_stats"
        self.headers = {
            "apikey": anon_key,
            "Authorization": f"Bearer {anon_key}",
            "Content-Type": "application/json",
            "Prefer": "resolution=merge-duplicates"
        }

    async def push_stats(self):
        async with aiohttp.ClientSession() as session:
            payload = {
                "id": self.tracking_key,
                "user_id": self.user_id,
                "name": "${selectedBot?.name || selectedBot?.username || 'Optional Name'}",
                "cpu_usage": psutil.cpu_percent(),
                "ram_usage": f"{psutil.virtual_memory().used / (1024 * 1024):.1f}MB",
                "status": 'online',
                "guild_count": len(self.bot.guilds)
            }
            try:
                async with session.post(self.url, headers=self.headers, json=payload) as resp:
                    if resp.status in [200, 201, 204]:
                        # Success
                        pass
                    else:
                        print(f"[BotOps] Update failed: {resp.status}")
            except Exception as e:
                print(f"[BotOps] Connection error: {e}")

    def start_loop(self, interval=60):
        async def stats_loop():
            await self.bot.wait_until_ready()
            while not self.bot.is_closed():
                await self.push_stats()
                await asyncio.sleep(interval)
        
        if hasattr(self.bot, 'loop'):
            self.bot.loop.create_task(stats_loop())
        else:
            asyncio.create_task(stats_loop())
`;

  const starterKitUsage = `# Usage Example:
from botops_connector import BotOpsConnector

# Inside your bot setup:
connector = BotOpsConnector(
    bot=bot,
    tracking_key="${trackingKey}",
    user_id="${userId || 'YOUR_USER_ID'}",
    supabase_url="${supabaseUrl}",
    anon_key="${supabaseAnonKey}"
)
connector.start_loop(interval=60)`;

  const handleDownload = () => {
    const element = document.createElement("a");
    const file = new Blob([starterKitCode], {type: 'text/plain'});
    element.href = URL.createObjectURL(file);
    element.download = "botops_connector.py";
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
    if (onDownload) onDownload();
  };

  const features = [
    {
      icon: LayoutDashboard,
      title: t.dashboard,
      description: t.dashboard_desc || "Monitor all your Discord bots in one central place. Track server counts, uptime, and system health across global clusters."
    },
    {
      icon: Terminal,
      title: t.analysis,
      description: t.analysis_desc || "Paste your bot logs or tracebacks to get instant AI-powered analysis. Identify bugs, performance bottlenecks, and security risks automatically."
    },
    {
      icon: ShieldCheck,
      title: t.security_compliance,
      description: t.security_desc || "Automated security checklists for every bot instance. We scan for token leaks, permission issues, and best practices."
    },
    {
      icon: Globe,
      title: t.global_distribution,
      description: t.distribution_desc || "Visualize where your bot traffic is coming from. Manage multi-region deployments and monitor latency from different nodes."
    }
  ];

  const steps = [
    {
      title: t.register_bot || "Register your Bot",
      description: t.register_bot_desc || "Go to the Bot Manager and enter a name for your bot to generate a unique tracking key."
    },
    {
      title: t.integrate_api || "Integrate API",
      description: t.integrate_api_desc || "Use the generated tracking key in your bot's code to send real-time metrics via our POST API."
    },
    {
      title: t.monitor_analyze || "Monitor & Analyze",
      description: t.monitor_analyze_desc || "View live RAM, CPU, and engagement metrics. If issues occur, use Deep Analysis to fix them instantly."
    }
  ];

  return (
    <div className="max-w-5xl mx-auto space-y-12 pb-12">
      <div className="text-center space-y-4">
        <div className="inline-flex items-center gap-2 px-3 py-1 bg-primary/10 border border-primary/20 rounded-full text-primary text-xs font-bold uppercase tracking-widest">
          <Info className="w-3 h-3" />
          {t.platform_guide}
        </div>
        <h2 className="text-4xl font-bold text-white tracking-tight">{t.how_it_works}</h2>
        <p className="text-slate-400 max-w-2xl mx-auto">
          {t.how_it_works_desc}
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {features.map((f, i) => (
          <Card key={i} className="card-glass group hover:border-primary/50 transition-all duration-300">
            <CardHeader>
              <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center border border-primary/20 mb-4 group-hover:scale-110 transition-transform">
                <f.icon className="w-6 h-6 text-primary" />
              </div>
              <CardTitle className="text-white">{f.title}</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-slate-400 text-sm leading-relaxed">{f.description}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="space-y-8">
        <h3 className="text-2xl font-bold text-white text-center">{t.getting_started}</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 relative">
          <div className="hidden md:block absolute top-12 left-0 right-0 h-px bg-gradient-to-r from-transparent via-white/10 to-transparent z-0" />
          
          {steps.map((s, i) => (
            <div key={i} className="relative z-10 flex flex-col items-center text-center space-y-4">
              <div className="w-12 h-12 rounded-full bg-[#050505] border-2 border-primary flex items-center justify-center text-primary font-bold shadow-[0_0_20px_rgba(59,130,246,0.3)]">
                {i + 1}
              </div>
              <h4 className="text-lg font-bold text-white">{s.title}</h4>
              <p className="text-slate-400 text-xs leading-relaxed px-4">{s.description}</p>
            </div>
          ))}
        </div>
      </div>

      {/* API Documentation Section */}
      <div className="space-y-6">
        <div className="text-center space-y-2">
          <h3 className="text-2xl font-bold text-white">{t.api_docs}</h3>
          <p className="text-slate-400 text-sm">{t.api_docs_desc}</p>
        </div>
        
        <Card className="card-glass border-white/5 bg-white/[0.01]">
          <Tabs defaultValue="starter" className="w-full">
            <CardHeader>
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div>
                  <CardTitle className="text-sm font-bold text-white uppercase tracking-widest flex items-center gap-2">
                    <Code className="w-4 h-4 text-primary" />
                    {t.post_integration}
                  </CardTitle>
                  <CardDescription className="text-xs">
                    {t.post_integration_desc}
                  </CardDescription>
                </div>
                <div className="flex items-center gap-4">
                  <TabsList className="bg-black/40 border border-white/10 h-9">
                    <TabsTrigger value="starter" className="text-[10px] uppercase tracking-widest font-bold px-4 data-[state=active]:bg-primary/20 data-[state=active]:text-primary">
                      {t.starter_kit || "Starter-Kit"}
                    </TabsTrigger>
                    <TabsTrigger value="manual" className="text-[10px] uppercase tracking-widest font-bold px-4">
                      {t.manual || "Manual"}
                    </TabsTrigger>
                  </TabsList>
                  
                  {bots.length > 0 && (
                    <div className="flex items-center gap-2">
                      <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Bot:</span>
                      <select 
                        className="bg-black/40 border border-white/10 rounded px-2 py-1 text-[10px] text-white outline-none focus:border-primary/50"
                        value={selectedBotId}
                        onChange={(e) => setSelectedBotId(e.target.value)}
                      >
                        {bots.map(b => (
                          <option key={b.id} value={b.id}>{b.username}</option>
                        ))}
                      </select>
                    </div>
                  )}
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <TabsContent value="starter" className="mt-0 space-y-6">
                <div className="p-4 bg-primary/5 border border-primary/10 rounded-xl flex items-start gap-4">
                  <Zap className="w-5 h-5 text-primary shrink-0 mt-0.5" />
                  <div>
                    <p className="text-xs font-bold text-white uppercase tracking-widest mb-1">
                      {t.starter_kit_recommended || "Starter-Kit (Empfohlen)"}
                    </p>
                    <p className="text-[11px] text-slate-400 leading-relaxed">
                      Nutze unsere optimierte Klasse für eine asynchrone Anbindung, die deinen Bot nicht blockiert. 
                      Einfach herunterladen und in dein Projekt importieren.
                    </p>
                  </div>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest flex items-center gap-2">
                        <FileCode className="w-3 h-3" />
                        botops_connector.py
                      </p>
                      <div className="flex items-center gap-2">
                        <Button 
                          variant="ghost" 
                          size="sm" 
                          className="h-7 text-[10px] gap-2 text-primary hover:bg-primary/10"
                          onClick={handleDownload}
                        >
                          <Download className="w-3 h-3" />
                          {t.download || "Download .py"}
                        </Button>
                        <Button 
                          variant="ghost" 
                          size="icon" 
                          className="h-7 w-7 text-slate-500 hover:text-white"
                          onClick={() => copyToClipboard(starterKitCode, 'starter')}
                        >
                          {copiedId === 'starter' ? <Check className="w-3 h-3 text-emerald-500" /> : <Copy className="w-3 h-3" />}
                        </Button>
                      </div>
                    </div>
                    <pre className="p-4 bg-black/60 rounded-xl border border-white/5 font-mono text-[10px] text-slate-300 overflow-x-auto max-h-[300px] scrollbar-thin scrollbar-thumb-white/10">
                      <code>{starterKitCode}</code>
                    </pre>
                  </div>

                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest flex items-center gap-2">
                        <Terminal className="w-3 h-3" />
                        {t.usage_example || "Usage Example"}
                      </p>
                      <Button 
                        variant="ghost" 
                        size="icon" 
                        className="h-7 w-7 text-slate-500 hover:text-white"
                        onClick={() => copyToClipboard(starterKitUsage, 'usage')}
                      >
                        {copiedId === 'usage' ? <Check className="w-3 h-3 text-emerald-500" /> : <Copy className="w-3 h-3" />}
                      </Button>
                    </div>
                    <pre className="p-4 bg-black/60 rounded-xl border border-white/5 font-mono text-[10px] text-emerald-400 overflow-x-auto">
                      <code>{starterKitUsage}</code>
                    </pre>
                    <div className="p-3 bg-white/5 rounded-lg border border-white/5">
                      <p className="text-[10px] text-slate-500 leading-relaxed italic">
                        Initialisiere den Connector einfach mit deiner Bot-Instanz und rufe <code className="text-primary">start_loop()</code> auf.
                      </p>
                    </div>
                  </div>
                </div>
              </TabsContent>

              <TabsContent value="manual" className="mt-0">
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Python (Requests)</p>
                      <div className="flex items-center gap-2">
                        <Button 
                          variant="ghost" 
                          size="icon" 
                          className="h-6 w-6 text-slate-500 hover:text-white"
                          onClick={() => copyToClipboard(pythonCode, 'python')}
                        >
                          {copiedId === 'python' ? <Check className="w-3 h-3 text-emerald-500" /> : <Copy className="w-3 h-3" />}
                        </Button>
                      </div>
                    </div>
                    <pre className="p-4 bg-black/60 rounded-xl border border-white/5 font-mono text-[11px] text-slate-300 overflow-x-auto relative group">
                      <code>{pythonCode}</code>
                    </pre>
                  </div>

                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">JavaScript (Axios)</p>
                      <div className="flex items-center gap-2">
                        <Button 
                          variant="ghost" 
                          size="icon" 
                          className="h-6 w-6 text-slate-500 hover:text-white"
                          onClick={() => copyToClipboard(jsCode, 'js')}
                        >
                          {copiedId === 'js' ? <Check className="w-3 h-3 text-emerald-500" /> : <Copy className="w-3 h-3" />}
                        </Button>
                      </div>
                    </div>
                    <pre className="p-4 bg-black/60 rounded-xl border border-white/5 font-mono text-[11px] text-slate-300 overflow-x-auto relative group">
                      <code>{jsCode}</code>
                    </pre>
                  </div>
                </div>
              </TabsContent>
            </CardContent>
          </Tabs>

          <CardContent className="pt-0">
            <div className="p-4 bg-primary/5 border border-primary/10 rounded-xl">
              <div className="flex items-center gap-2 mb-2">
                <Activity className="w-4 h-4 text-primary" />
                <span className="text-xs font-bold text-white uppercase tracking-wider">{t.endpoint_details}</span>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <p className="text-[10px] text-slate-500 uppercase font-bold">{t.method}</p>
                  <p className="text-xs font-mono text-emerald-400 font-bold">POST</p>
                </div>
                <div>
                  <p className="text-[10px] text-slate-500 uppercase font-bold">{t.url}</p>
                  <p className="text-xs font-mono text-slate-300 break-all">{endpoint}</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card className="card-glass border-primary/30 overflow-hidden relative">
        <div className="absolute top-0 right-0 p-12 opacity-5">
          <Zap className="w-48 h-48 text-primary" />
        </div>
        <CardContent className="p-8 md:p-12 flex flex-col md:flex-row items-center gap-8 relative z-10">
          <div className="flex-1 space-y-4">
            <h3 className="text-2xl font-bold text-white">{t.ready_to_scale}</h3>
            <p className="text-slate-400">
              {t.ready_to_scale_desc}
            </p>
            <div className="flex flex-wrap gap-4 pt-2">
              <div className="flex items-center gap-2 text-xs text-emerald-400 font-bold uppercase tracking-widest">
                <CheckCircle2 className="w-4 h-4" />
                {t.no_credit_card}
              </div>
              <div className="flex items-center gap-2 text-xs text-emerald-400 font-bold uppercase tracking-widest">
                <CheckCircle2 className="w-4 h-4" />
                {t.free_for_devs}
              </div>
            </div>
          </div>
          <Button 
            className="btn-gradient h-12 px-8 font-bold gap-2 group"
            onClick={onGoToDashboard}
          >
            {t.go_to_dashboard}
            <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
