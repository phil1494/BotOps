import { useState } from "react";
import { motion } from "motion/react";
import { 
  Plus, 
  ShieldCheck, 
  Key, 
  AlertCircle,
  RefreshCw,
  Trash2,
  ExternalLink,
  Activity,
  Cpu,
  HardDrive,
  Clock,
  ArrowRight
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Bot } from "@/src/types";
import { cn } from "@/lib/utils";

interface BotManagerViewProps {
  bots: Bot[];
  onAddBot: (name: string) => Promise<string | undefined>;
  onRemoveBot: (id: string) => void;
  onGoToAnalysis?: () => void;
  t: any;
}

export function BotManagerView({ bots, onAddBot, onRemoveBot, onGoToAnalysis, t }: BotManagerViewProps) {
  const [nameInput, setNameInput] = useState("");
  const [isAdding, setIsAdding] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [newTrackingKey, setNewTrackingKey] = useState<string | null>(null);

  const handleAdd = async () => {
    if (!nameInput.trim()) return;
    setIsAdding(true);
    setError(null);
    try {
      const key = await onAddBot(nameInput);
      if (key) {
        setNewTrackingKey(key);
        setNameInput("");
      }
    } catch (err: any) {
      setError(err.message || "Failed to register bot.");
    } finally {
      setIsAdding(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      <div>
        <h2 className="text-3xl font-bold text-white tracking-tight">{t.manager}</h2>
        <p className="text-slate-400 mt-1">{t.manager_desc}</p>
      </div>

      <Card className="card-glass shadow-2xl overflow-hidden relative">
        <div className="absolute top-0 right-0 p-8 opacity-5">
          <Activity className="w-32 h-32" />
        </div>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Plus className="w-5 h-5 text-primary" />
            {t.register_new_bot}
          </CardTitle>
          <CardDescription>
            {t.register_new_bot_desc}
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex gap-3">
            <Input
              placeholder={t.bot_name_placeholder}
              className="bg-[#0f172a] border-white/10 h-12 text-sm text-white focus:border-primary/50 transition-all"
              value={nameInput}
              onChange={(e) => setNameInput(e.target.value)}
            />
            <Button 
              className="btn-gradient h-12 px-8 font-bold relative z-10"
              onClick={handleAdd}
              disabled={isAdding || !nameInput}
            >
              {isAdding ? <RefreshCw className="w-4 h-4 animate-spin mr-2" /> : <Plus className="w-4 h-4 mr-2" />}
              {t.register}
            </Button>
          </div>

          {error && (
            <motion.div 
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              className="p-3 bg-rose-500/10 border border-rose-500/20 rounded-lg flex items-center gap-3 text-rose-400 text-xs"
            >
              <AlertCircle className="w-4 h-4 shrink-0" />
              {error}
            </motion.div>
          )}

          {newTrackingKey && (
            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              className="p-4 bg-emerald-500/10 border border-emerald-500/20 rounded-xl space-y-3"
            >
              <div className="flex items-center justify-between">
                <p className="text-xs font-bold text-emerald-500 uppercase tracking-widest">{t.tracking_key_generated}</p>
                <Button variant="ghost" size="sm" className="h-6 text-[10px]" onClick={() => setNewTrackingKey(null)}>{t.close}</Button>
              </div>
              <div className="flex gap-2">
                <code className="flex-1 p-2 bg-black/40 rounded border border-white/10 text-emerald-400 font-mono text-xs break-all">
                  {newTrackingKey}
                </code>
                <Button 
                  variant="outline" 
                  size="sm" 
                  className="h-8 border-emerald-500/30 text-emerald-500 hover:bg-emerald-500/10"
                  onClick={() => navigator.clipboard.writeText(newTrackingKey)}
                >
                  {t.copy}
                </Button>
              </div>
              <p className="text-[10px] text-slate-400">{t.save_key_desc}</p>
            </motion.div>
          )}

          <div className="p-4 bg-primary/5 border border-primary/10 rounded-xl flex items-start gap-4">
            <ShieldCheck className="w-5 h-5 text-primary shrink-0 mt-0.5" />
            <div>
              <p className="text-xs font-bold text-primary uppercase tracking-widest mb-1">{t.secure_integration}</p>
              <p className="text-[11px] text-slate-400 leading-relaxed">
                {t.secure_integration_desc}
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="space-y-6">
        <div className="flex items-center justify-between px-1">
          <h3 className="text-sm font-bold text-slate-400 uppercase tracking-widest">{t.active_instances_monitoring}</h3>
          <Badge variant="outline" className="text-[10px] border-emerald-500/30 text-emerald-500 bg-emerald-500/5">{t.live_updates}</Badge>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {bots.filter(b => b.status !== 'offline').length === 0 ? (
            <div className="col-span-full p-8 border border-dashed border-white/5 rounded-2xl text-center">
              <p className="text-slate-500 italic text-sm">{t.no_active_bots}</p>
            </div>
          ) : (
            bots.filter(b => b.status !== 'offline').map((bot, i) => (
              <Card key={bot.id} className="card-glass hover-glow border-white/5 bg-white/[0.02] group">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center gap-3">
                      <div className="relative">
                        <div className={cn("w-2 h-2 rounded-full animate-pulse", bot.status === 'online' ? "bg-emerald-500" : "bg-amber-500")} />
                        <div className={cn("absolute inset-0 w-2 h-2 rounded-full blur-[4px] animate-pulse", bot.status === 'online' ? "bg-emerald-500" : "bg-amber-500")} />
                      </div>
                      <div className="flex flex-col truncate max-w-[120px]">
                        <span className="text-sm font-bold text-white truncate">{bot.name || bot.username}</span>
                        {bot.name && <span className="text-[10px] text-slate-500 truncate">{bot.username}</span>}
                      </div>
                    </div>
                    <Badge variant="outline" className={cn("text-[9px] h-5 px-2", bot.status === 'online' ? "bg-emerald-500/10 text-emerald-500 border-emerald-500/20" : "bg-amber-500/10 text-amber-500 border-amber-500/20")}>
                      {bot.status === 'online' ? t.stable : t.warning}
                    </Badge>
                  </div>
                  
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2 text-slate-400">
                        <Cpu className="w-3.5 h-3.5" />
                        <span className="text-[11px] font-medium uppercase tracking-wider">{t.cpu}</span>
                      </div>
                      <span className="text-xs font-mono font-bold text-primary">{(bot.cpu_usage || 0).toFixed(1)}%</span>
                    </div>
                    <div className="w-full h-1 bg-white/5 rounded-full overflow-hidden">
                      <motion.div 
                        className="h-full bg-primary"
                        animate={{ width: `${bot.cpu_usage || 0}%` }}
                        transition={{ duration: 0.5 }}
                      />
                    </div>

                    <div className="flex items-center justify-between pt-1">
                      <div className="flex items-center gap-2 text-slate-400">
                        <HardDrive className="w-3.5 h-3.5" />
                        <span className="text-[11px] font-medium uppercase tracking-wider">{t.ram}</span>
                      </div>
                      <span className="text-xs font-mono text-slate-300">{bot.ram_usage || "0MB"}</span>
                    </div>

                    <div className="flex items-center justify-between pt-1">
                      <div className="flex items-center gap-2 text-slate-400">
                        <Clock className="w-3.5 h-3.5" />
                        <span className="text-[11px] font-medium uppercase tracking-wider">{t.last_ping}</span>
                      </div>
                      <span className="text-xs font-mono text-slate-300">
                        {bot.last_ping ? new Date(bot.last_ping).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }) : t.never}
                      </span>
                    </div>
                  </div>

                  <Button 
                    variant="ghost" 
                    className="w-full mt-4 h-8 text-[10px] gap-2 text-slate-500 hover:text-primary hover:bg-primary/5 border border-transparent hover:border-primary/20 transition-all opacity-0 group-hover:opacity-100"
                    onClick={onGoToAnalysis}
                  >
                    {t.deep_analysis} <ArrowRight className="w-3 h-3" />
                  </Button>
                </CardContent>
              </Card>
            ))
          )}
        </div>
      </div>

      <div className="space-y-4">
        <h3 className="text-sm font-bold text-slate-400 uppercase tracking-widest px-1">{t.connected_bots_count?.replace('{count}', bots.length.toString())}</h3>
        <div className="grid gap-3">
          {bots.length === 0 ? (
            <div className="p-12 border border-dashed border-white/5 rounded-2xl text-center">
              <p className="text-slate-500 italic text-sm">{t.no_bots_connected}</p>
            </div>
          ) : (
            bots.map((bot) => (
              <Card key={bot.id} className="card-glass hover:border-primary/30 transition-all">
                <CardContent className="p-4 flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <Avatar className="w-10 h-10 border border-white/10">
                      <AvatarImage src={bot.avatar || ""} />
                      <AvatarFallback className="bg-primary/20 text-primary font-bold">
                        {(bot.name || bot.username).substring(0, 2).toUpperCase()}
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <h4 className="font-bold text-white text-sm">
                        {bot.name || bot.username}
                        <span className="text-slate-500 font-normal ml-1">
                          {bot.name ? `(${bot.username}#${bot.discriminator})` : `#${bot.discriminator}`}
                        </span>
                      </h4>
                      <p className="text-[10px] text-slate-500 font-mono">ID: {bot.discord_id || bot.id.substring(0, 8)}</p>
                      {bot.security_checklist && bot.security_checklist.length > 0 && (
                        <div className="mt-2 space-y-1">
                          <p className="text-[9px] font-bold text-amber-500 uppercase tracking-widest">{t.security_checklist}</p>
                          {bot.security_checklist.map((item, idx) => (
                            <div key={idx} className="flex items-center gap-1.5">
                              <div className="w-1 h-1 rounded-full bg-amber-500" />
                              <p className="text-[10px] text-slate-400">{item}</p>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>
                  <div className="flex items-center gap-4">
                    <div className="text-right hidden sm:block">
                      <p className="text-[10px] text-slate-500 uppercase font-bold">{t.servers}</p>
                      <p className="text-sm font-bold text-white">{bot.guild_count}</p>
                    </div>
                    <div className="w-px h-8 bg-white/5 hidden sm:block" />
                    <div className="flex gap-2">
                      <Button 
                        variant="ghost" 
                        size="icon" 
                        className="h-9 w-9 text-slate-500 hover:text-primary hover:bg-primary/5 relative z-10"
                        onClick={(e) => {
                          e.stopPropagation();
                          // In production, this would trigger a real data refresh
                        }}
                      >
                        <RefreshCw className="w-4 h-4" />
                      </Button>
                      <Button 
                        variant="ghost" 
                        size="icon" 
                        className="h-9 w-9 text-slate-500 hover:text-white hover:bg-white/5 relative z-10"
                        onClick={(e) => {
                          e.stopPropagation();
                          window.open("https://discord.com/developers/applications", "_blank");
                        }}
                      >
                        <ExternalLink className="w-4 h-4" />
                      </Button>
                      <Button 
                        variant="ghost" 
                        size="icon" 
                        className="h-9 w-9 text-slate-500 hover:text-rose-400 hover:bg-rose-400/5 relative z-10"
                        onClick={(e) => {
                          e.stopPropagation();
                          onRemoveBot(bot.id);
                        }}
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
