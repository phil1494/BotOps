import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  Users, 
  Activity, 
  Server, 
  ChevronRight,
  MoreVertical,
  Eye,
  EyeOff,
  Key,
  CheckCircle2,
  Circle,
  ArrowRight,
  Download,
  Bot as BotIcon,
  Zap
} from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Bot } from "@/src/types";
import { cn } from "@/lib/utils";

interface DashboardViewProps {
  bots: Bot[];
  totalServers: number;
  avgCpu: number;
  totalRam: number;
  onSelectBot: (id: string) => void;
  onAddBotClick: () => void;
  t: any;
  starterKitDownloaded?: boolean;
}

export function DashboardView({ 
  bots, 
  totalServers, 
  avgCpu, 
  totalRam, 
  onSelectBot, 
  onAddBotClick, 
  t,
  starterKitDownloaded = false
}: DashboardViewProps) {
  const hasActivePing = bots.some(bot => bot.last_ping);
  const showOnboarding = bots.length === 0 || bots.every(bot => bot.status === 'offline' && !bot.last_ping);

  const steps = [
    {
      id: 1,
      title: t.onboarding_step1 || "Bot im Manager registrieren",
      completed: bots.length > 0,
      icon: BotIcon
    },
    {
      id: 2,
      title: t.onboarding_step2 || "Starter-Kit herunterladen",
      completed: starterKitDownloaded,
      icon: Download
    },
    {
      id: 3,
      title: t.onboarding_step3 || "Ersten Live-Ping empfangen",
      completed: hasActivePing,
      icon: Activity
    }
  ];

  return (
    <div className="space-y-8">
      <AnimatePresence mode="wait">
        {showOnboarding && !hasActivePing ? (
          <motion.div
            key="onboarding"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95 }}
            className="space-y-6"
          >
            <div className="flex flex-col items-center text-center space-y-4 mb-8">
              <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center border border-primary/20">
                <Zap className="w-8 h-8 text-primary animate-pulse" />
              </div>
              <h2 className="text-3xl font-bold text-white tracking-tight">Onboarding-Checkliste</h2>
              <p className="text-slate-400 max-w-md">
                Verbinde deinen ersten Bot, um Live-Metriken und AI-Analysen freizuschalten.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {steps.map((step, i) => (
                <Card 
                  key={step.id} 
                  className={cn(
                    "card-glass p-6 transition-all duration-500 relative overflow-hidden group",
                    step.completed ? "border-emerald-500/30 bg-emerald-500/5" : "border-white/5"
                  )}
                >
                  {step.completed && (
                    <div className="absolute top-0 right-0 p-2">
                      <CheckCircle2 className="w-5 h-5 text-emerald-500" />
                    </div>
                  )}
                  <div className="flex flex-col items-center text-center space-y-4">
                    <div className={cn(
                      "w-12 h-12 rounded-xl flex items-center justify-center border transition-all duration-500",
                      step.completed 
                        ? "bg-emerald-500/20 border-emerald-500/30 text-emerald-500" 
                        : "bg-white/5 border-white/10 text-slate-500 group-hover:border-primary/30 group-hover:text-primary"
                    )}>
                      <step.icon className="w-6 h-6" />
                    </div>
                    <div>
                      <h3 className={cn(
                        "text-sm font-bold uppercase tracking-widest",
                        step.completed ? "text-emerald-400" : "text-slate-400"
                      )}>
                        {step.title}
                      </h3>
                    </div>
                    {!step.completed && i === 0 && (
                      <Button variant="ghost" size="sm" onClick={onAddBotClick} className="text-[10px] uppercase tracking-widest font-bold gap-2 text-primary hover:bg-primary/10">
                        Manager öffnen <ArrowRight className="w-3 h-3" />
                      </Button>
                    )}
                  </div>
                </Card>
              ))}
            </div>
          </motion.div>
        ) : (
          <motion.div
            key="dashboard-content"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="space-y-8"
          >
            <div className="flex items-end justify-between">
              <div>
                <h2 className="text-3xl font-bold text-white tracking-tight">{t.dashboard}</h2>
                <p className="text-slate-400 mt-1">{t.monitoring_desc?.replace('{count}', bots.length.toString()) || `Monitoring ${bots.length} active bot instances across global clusters.`}</p>
              </div>
              <div className="flex gap-4">
                <div className="text-right">
                  <p className="text-[10px] uppercase tracking-widest text-slate-500 font-bold">{t.total_servers}</p>
                  <p className="text-xl font-bold text-white">{totalServers.toLocaleString()}</p>
                </div>
                <div className="w-px h-10 bg-white/10" />
                <div className="text-right">
                  <p className="text-[10px] uppercase tracking-widest text-slate-500 font-bold">{t.avg_health}</p>
                  <p className="text-xl font-bold text-emerald-400">
                    {bots.length > 0 
                      ? `${((bots.filter(b => b.status === 'online').length / bots.length) * 100).toFixed(1)}%` 
                      : "100%"}
                  </p>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <Card className="card-glass p-4">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-primary/20 flex items-center justify-center border border-primary/30">
                    <Server className="w-5 h-5 text-primary" />
                  </div>
                  <div>
                    <p className="text-[10px] uppercase tracking-widest text-slate-500 font-bold">{t.total_clusters}</p>
                    <p className="text-xl font-bold text-white">{bots.length} Nodes</p>
                  </div>
                </div>
              </Card>
              <Card className="card-glass p-4">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-emerald-500/20 flex items-center justify-center border border-emerald-500/30">
                    <Activity className="w-5 h-5 text-emerald-500" />
                  </div>
                  <div>
                    <p className="text-[10px] uppercase tracking-widest text-slate-500 font-bold">{t.avg_cpu}</p>
                    <p className="text-xl font-bold text-white">{avgCpu.toFixed(1)}%</p>
                  </div>
                </div>
              </Card>
              <Card className="card-glass p-4">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-indigo-500/20 flex items-center justify-center border border-indigo-500/30">
                    <Users className="w-5 h-5 text-indigo-500" />
                  </div>
                  <div>
                    <p className="text-[10px] uppercase tracking-widest text-slate-500 font-bold">{t.ram_usage}</p>
                    <p className="text-xl font-bold text-white">{totalRam.toFixed(0)} MB</p>
                  </div>
                </div>
              </Card>
              <Card className="card-glass p-4">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-amber-500/20 flex items-center justify-center border border-amber-500/30">
                    <Key className="w-5 h-5 text-amber-500" />
                  </div>
                  <div>
                    <p className="text-[10px] uppercase tracking-widest text-slate-500 font-bold">{t.active_shards}</p>
                    <p className="text-xl font-bold text-white">{bots.length * 4}</p>
                  </div>
                </div>
              </Card>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
              {bots.length === 0 ? (
                <Card className="col-span-full card-glass border-dashed p-12 flex flex-col items-center justify-center text-center">
                  <div className="w-16 h-16 bg-white/5 rounded-full flex items-center justify-center mb-4">
                    <Server className="w-8 h-8 text-slate-600" />
                  </div>
                  <h3 className="text-lg font-semibold text-white">{t.no_bots_connected}</h3>
                  <p className="text-slate-400 max-w-xs mt-2 mb-6">{t.no_bots_desc}</p>
                  <Button 
                    onClick={onAddBotClick}
                    className="btn-gradient font-bold px-8 h-12"
                  >
                    {t.register_new_bot}
                  </Button>
                </Card>
              ) : (
                bots.map((bot, i) => {
                  return (
                    <motion.div
                      key={bot.id}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: i * 0.1 }}
                    >
                      <Card className="card-glass hover:border-primary/50 transition-all duration-300 group cursor-pointer overflow-hidden relative">
                        <div className="absolute inset-0 bg-gradient-to-br from-primary/10 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
                        <CardContent className="p-6 relative">
                          <div className="flex items-start justify-between mb-6">
                            <div className="flex items-center gap-4">
                              <div className="relative">
                                <Avatar className="w-14 h-14 border-2 border-[#050505] group-hover:border-primary/50 transition-colors">
                                  <AvatarImage src={bot.avatar || ""} />
                                  <AvatarFallback className="bg-primary/20 text-primary font-bold">
                                    {bot.username.substring(0, 2).toUpperCase()}
                                  </AvatarFallback>
                                </Avatar>
                                <div className={`absolute -bottom-1 -right-1 w-4 h-4 rounded-full border-2 border-[#050505] ${
                                  bot.status === 'online' ? 'bg-emerald-500' : 
                                  bot.status === 'warning' ? 'bg-amber-500' : 'bg-rose-500'
                                }`} />
                              </div>
                              <div>
                                <div className="flex items-center gap-2">
                                  <h3 className="font-bold text-white text-lg group-hover:text-primary transition-colors">{bot.username}</h3>
                                  <Badge 
                                    variant="outline" 
                                    className={`text-[9px] uppercase tracking-tighter h-4 px-1.5 border-none ${
                                      bot.status === 'online' ? 'bg-emerald-500/10 text-emerald-500' : 
                                      bot.status === 'warning' ? 'bg-amber-500/10 text-amber-500' : 
                                      'bg-rose-500/10 text-rose-500'
                                    }`}
                                  >
                                    {bot.status}
                                  </Badge>
                                </div>
                                <p className="text-xs text-slate-400 font-mono">#{bot.discriminator}</p>
                              </div>
                            </div>
                            <button 
                              className="text-slate-500 hover:text-white transition-colors p-1"
                              onClick={(e) => {
                                e.stopPropagation();
                                // Quick actions menu could be implemented here
                              }}
                            >
                              <MoreVertical className="w-5 h-5" />
                            </button>
                          </div>

                          {bot.mood_summary && (
                            <div className="mb-4 p-2 bg-primary/5 border border-primary/10 rounded-lg">
                              <p className="text-[10px] text-primary font-bold uppercase tracking-widest mb-1">{t.ai_mood_summary}</p>
                              <p className="text-xs text-slate-300 italic">"{bot.mood_summary}"</p>
                            </div>
                          )}

                          <TrackingKeyDisplay trackingKey={bot.tracking_key} />

                          <div className="grid grid-cols-2 gap-4 mb-6">
                            <div className="p-3 bg-white/5 rounded-xl border border-white/5">
                              <div className="flex items-center gap-2 mb-1">
                                <Users className="w-3 h-3 text-slate-400" />
                                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">{t.servers}</span>
                              </div>
                              <p className="text-lg font-bold text-white">{bot.guild_count.toLocaleString()}</p>
                            </div>
                            <div className="p-3 bg-white/5 rounded-xl border border-white/5">
                              <div className="flex items-center gap-2 mb-1">
                                <Activity className="w-3 h-3 text-slate-400" />
                                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">{t.cpu}</span>
                              </div>
                              <p className="text-lg font-bold text-emerald-400">{(bot.cpu_usage || 0).toFixed(1)}%</p>
                            </div>
                          </div>

                          <div className="flex items-center justify-between text-xs">
                            <Badge variant="outline" className="bg-white/5 border-white/10 text-slate-400 font-mono text-[10px]">
                              ID: {bot.username || bot.id.substring(0, 8)}
                            </Badge>
                            <button 
                              onClick={(e) => {
                                e.stopPropagation();
                                onSelectBot(bot.id);
                              }}
                              className="btn-gradient flex items-center gap-1 px-4 py-1.5 rounded-lg transition-all group/btn shadow-[0_0_20px_rgba(59,130,246,0.2)]"
                            >
                              <span className="font-bold uppercase tracking-widest text-[10px] text-white">{t.details}</span>
                              <ChevronRight className="w-3 h-3 text-white group-hover/btn:translate-x-1 transition-transform" />
                            </button>
                          </div>
                        </CardContent>
                      </Card>
                    </motion.div>
                  );
                })
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

function TrackingKeyDisplay({ trackingKey }: { trackingKey: string }) {
  const [showKey, setShowKey] = useState(false);
  return (
    <div className="mb-4 p-3 bg-black/40 border border-white/5 rounded-xl flex items-center justify-between group/token">
      <div className="flex items-center gap-2 overflow-hidden">
        <Key className="w-3 h-3 text-slate-500 shrink-0" />
        <p className="text-[10px] font-mono text-slate-400 truncate">
          {showKey ? trackingKey : "••••••••-••••-••••-••••-••••••••••••"}
        </p>
      </div>
      <button 
        onClick={(e) => {
          e.stopPropagation();
          setShowKey(!showKey);
        }}
        className="text-slate-600 hover:text-white transition-colors p-1"
      >
        {showKey ? <EyeOff className="w-3 h-3" /> : <Eye className="w-3 h-3" />}
      </button>
    </div>
  );
}
