import React, { useState } from "react";
import { motion } from "motion/react";
import { 
  Zap, 
  ArrowRight, 
  Loader2,
  AlertCircle,
  MessageCircle
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { supabase } from "@/src/lib/supabaseClient";
import { Language, translations } from "@/src/lib/translations";

export function Login() {
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  
  // Detect language from localStorage or default to 'de'
  const [language] = useState<Language>(() => {
    const saved = localStorage.getItem("botops_language");
    return (saved as Language) || 'de';
  });
  
  const t = translations[language];

  const handleDiscordLogin = async () => {
    setIsLoading(true);
    setError(null);

    try {
      const redirectTo = import.meta.env.VITE_SITE_URL || window.location.origin;
      const { error } = await supabase.auth.signInWithOAuth({
        provider: 'discord',
        options: {
          redirectTo
        }
      });
      if (error) {
        console.error("Supabase OAuth Error:", error);
        throw error;
      }
    } catch (err: any) {
      console.error("Discord Login Catch:", err);
      setError(err.message || "An error occurred during Discord authentication.");
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#050505] flex items-center justify-center p-4 selection:bg-primary/30">
      {/* Background Glow */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute -top-[20%] -left-[10%] w-[60%] h-[60%] bg-primary/10 blur-[120px] rounded-full" />
        <div className="absolute -bottom-[20%] -right-[10%] w-[60%] h-[60%] bg-indigo-500/10 blur-[120px] rounded-full" />
      </div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="w-full max-w-md relative z-10"
      >
        <div className="flex flex-col items-center mb-8">
          <div className="w-16 h-16 bg-primary/20 rounded-2xl flex items-center justify-center border border-primary/30 shadow-[0_0_30px_rgba(59,130,246,0.3)] mb-4">
            <Zap className="w-8 h-8 text-primary fill-primary/20" />
          </div>
          <h1 className="text-3xl font-bold text-white tracking-tight">BotOps Cloud</h1>
          <p className="text-slate-400 font-mono text-xs uppercase tracking-[0.3em] mt-2">Intelligence Dashboard</p>
        </div>

        <Card className="card-glass shadow-2xl">
          <CardHeader>
            <CardTitle className="text-xl text-white">{t.welcome}</CardTitle>
            <CardDescription className="text-slate-400">
              {t.login_desc}
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <Button 
              onClick={handleDiscordLogin}
              className="w-full h-12 bg-[#5865F2] hover:bg-[#4752C4] text-white font-bold shadow-lg shadow-[#5865F2]/20 group transition-all"
              disabled={isLoading}
            >
              {isLoading ? (
                <Loader2 className="w-5 h-5 animate-spin" />
              ) : (
                <>
                  <MessageCircle className="w-5 h-5 mr-2 fill-white" />
                  {t.login_discord}
                  <ArrowRight className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform" />
                </>
              )}
            </Button>

            {error && (
              <div className="p-3 rounded-lg flex items-center gap-3 text-xs bg-rose-500/10 text-rose-400 border border-rose-500/20">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <p>{error}</p>
              </div>
            )}

            <div className="pt-4 border-t border-white/5">
              <p className="text-[10px] text-slate-500 text-center leading-relaxed">
                {t.terms_privacy}
              </p>
            </div>
          </CardContent>
        </Card>

        <p className="text-center mt-8 text-[10px] text-slate-500 uppercase tracking-widest font-mono">
          &copy; 2026 BotOps Intelligence Systems
        </p>
      </motion.div>
    </div>
  );
}
