import { useState, useEffect } from "react";
import { motion } from "motion/react";
import { 
  LayoutDashboard, 
  Zap, 
  Bot as BotIcon, 
  LogOut,
  MessageCircle,
  X,
  Globe,
  Palette,
  Moon,
  Sun,
  Monitor,
  ChevronDown,
  ChevronUp,
  Check
} from "lucide-react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { supabase } from "@/src/lib/supabaseClient";
import { Language } from "@/src/lib/translations";

interface SidebarProps {
  activeView: string;
  setActiveView: (view: string) => void;
  notificationsCount?: number;
  onClose?: () => void;
  t: any;
  language: Language;
  onLanguageChange: (lang: Language) => void;
  themeColor: string;
  onThemeColorChange: (color: string) => void;
  themeMode: 'auto' | 'light' | 'dark';
  onThemeModeChange: (mode: 'auto' | 'light' | 'dark') => void;
}

export function Sidebar({ 
  activeView, 
  setActiveView, 
  notificationsCount = 0, 
  onClose, 
  t,
  language,
  onLanguageChange,
  themeColor,
  onThemeColorChange,
  themeMode,
  onThemeModeChange
}: SidebarProps) {
  const [user, setUser] = useState<any>(null);
  const [isSettingsOpen, setIsSettingsOpen] = useState(true);
  const [isLangSelectorOpen, setIsLangSelectorOpen] = useState(false);

  useEffect(() => {
    supabase.auth.getUser().then(({ data: { user } }) => {
      setUser(user);
    });
  }, []);

  const languages: { label: string, code: Language }[] = [
    { label: "DE", code: 'de' },
    { label: "EN", code: 'en' },
    { label: "FR", code: 'fr' },
    { label: "ES", code: 'es' },
    { label: "IT", code: 'it' },
  ];

  const colors = [
    { value: 'blue', hex: '#3b82f6' },
    { value: 'violet', hex: '#8b5cf6' },
    { value: 'green', hex: '#10b981' },
    { value: 'red', hex: '#ef4444' },
    { value: 'yellow', hex: '#eab308' },
    { value: 'orange', hex: '#f97316' },
    { value: 'pink', hex: '#ec4899' },
  ];

  return (
    <aside className="w-64 border-r border-white/5 bg-[#050505] lg:bg-black/40 backdrop-blur-xl flex flex-col h-screen sticky top-0 z-50 relative">
      <div className="p-6 flex items-center justify-between border-b border-white/5">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 bg-primary/20 rounded-lg flex items-center justify-center border border-primary/30 shadow-[0_0_15px_rgba(59,130,246,0.2)]">
            <Zap className="w-5 h-5 text-primary fill-primary/20" />
          </div>
          <div>
            <h1 className="text-lg font-bold tracking-tight text-white leading-none">BotOps</h1>
            <p className="text-[9px] uppercase tracking-[0.2em] text-slate-500 font-mono mt-1">Intelligence</p>
          </div>
        </div>
        {onClose && (
          <Button 
            variant="ghost" 
            size="icon" 
            className="lg:hidden text-slate-500 hover:text-white"
            onClick={onClose}
          >
            <X className="w-5 h-5" />
          </Button>
        )}
      </div>

      <nav className="flex-1 p-4 space-y-2 overflow-y-auto custom-scrollbar">
        {[
          { id: "dashboard", label: t.dashboard, icon: LayoutDashboard },
          { id: "analysis", label: t.analysis, icon: Zap, badge: notificationsCount },
          { id: "manager", label: t.manager, icon: BotIcon },
          { id: "info", label: t.info, icon: MessageCircle },
        ].map((item) => (
          <Button
            key={item.id}
            variant="ghost"
            className={cn(
              "w-full justify-start gap-3 h-11 transition-all duration-200 group relative",
              activeView === item.id 
                ? "bg-primary/10 text-primary border-l-2 border-primary rounded-l-none" 
                : "text-slate-400 hover:text-white hover:bg-white/5 active:scale-[0.98]"
            )}
            onClick={(e) => {
              e.preventDefault();
              setActiveView(item.id);
            }}
          >
            <item.icon className={cn(
              "w-5 h-5 transition-transform duration-200",
              activeView === item.id ? "scale-110" : "group-hover:scale-110"
            )} />
            <span className="font-medium">{item.label}</span>
            {item.badge > 0 && (
              <span className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 bg-rose-500 text-white text-[10px] font-bold rounded-full flex items-center justify-center animate-pulse">
                {item.badge}
              </span>
            )}
          </Button>
        ))}
        {/* Settings Section */}
        <div className="mt-4 pt-4 border-t border-white/5">
          <button 
            onClick={() => setIsSettingsOpen(!isSettingsOpen)}
            className="w-full flex items-center justify-between px-4 mb-2 group"
          >
            <span className="text-[10px] font-bold text-slate-500 uppercase tracking-[0.2em] group-hover:text-slate-300 transition-colors">
              {t.settings}
            </span>
            {isSettingsOpen ? <ChevronUp className="w-3 h-3 text-slate-600" /> : <ChevronDown className="w-3 h-3 text-slate-600" />}
          </button>

          {isSettingsOpen && (
            <div className="space-y-1 px-2">
              {/* Language Selector */}
              <div className="relative">
                <button 
                  onClick={() => setIsLangSelectorOpen(!isLangSelectorOpen)}
                  className={cn(
                    "w-full flex items-center justify-between px-3 py-2 rounded-lg transition-all text-xs group relative overflow-hidden",
                    isLangSelectorOpen ? "bg-primary/20 text-white" : "hover:bg-white/5 text-slate-400 hover:text-white"
                  )}
                >
                  <div className="flex items-center gap-3">
                    <Globe className={cn(
                      "w-4 h-4 transition-colors",
                      isLangSelectorOpen ? "text-primary" : "text-slate-500 group-hover:text-primary"
                    )} />
                    <span className="font-medium">{t.language}</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <span className="text-[10px] font-bold bg-white/10 px-1.5 py-0.5 rounded text-slate-300 uppercase tracking-tighter">
                      {language}
                    </span>
                    <ChevronDown className={cn("w-3 h-3 transition-transform duration-300", isLangSelectorOpen && "rotate-180")} />
                  </div>
                </button>
                
                {isLangSelectorOpen && (
                  <div className="absolute bottom-full left-0 w-full mb-2 bg-[#0a0b0e] border border-white/10 rounded-xl shadow-[0_20px_50px_rgba(0,0,0,0.5)] p-1.5 z-[60] grid grid-cols-5 gap-1 animate-in fade-in slide-in-from-bottom-2 duration-200">
                    {languages.map((lang) => (
                      <button
                        key={lang.code}
                        onClick={() => {
                          onLanguageChange(lang.code);
                          setIsLangSelectorOpen(false);
                        }}
                        className={cn(
                          "flex flex-col items-center justify-center py-2.5 rounded-lg transition-all text-[10px] font-bold active:scale-90 relative",
                          language === lang.code 
                            ? "bg-primary text-white shadow-[0_0_15px_rgba(var(--primary),0.4)]" 
                            : "hover:bg-white/10 text-slate-500 hover:text-white"
                        )}
                      >
                        {lang.label}
                        {language === lang.code && (
                          <Check className="w-2 h-2 absolute top-1 right-1" />
                        )}
                      </button>
                    ))}
                  </div>
                )}
              </div>

              {/* Color Selector */}
              <div className="px-3 py-2 rounded-lg hover:bg-white/5 transition-all group">
                <div className="flex items-center gap-3 mb-3">
                  <Palette className="w-4 h-4 text-slate-500 group-hover:text-primary transition-colors" />
                  <span className="text-xs font-medium text-slate-400 group-hover:text-white">{t.colors}</span>
                </div>
                <div className="flex flex-wrap items-center gap-2.5 pl-7">
                  {colors.map((c) => (
                    <button
                      key={c.value}
                      onClick={() => onThemeColorChange(c.value)}
                      className={cn(
                        "w-5 h-5 rounded-full transition-all hover:scale-125 active:scale-95 relative group/color",
                        themeColor === c.value 
                          ? "scale-110 z-10" 
                          : "opacity-60 hover:opacity-100"
                      )}
                      style={{ backgroundColor: c.hex }}
                      title={c.value}
                    >
                      {/* Active Ring */}
                      {themeColor === c.value && (
                        <motion.div 
                          layoutId="activeColor"
                          className="absolute -inset-1 border-2 border-white rounded-full shadow-[0_0_15px_rgba(255,255,255,0.3)] flex items-center justify-center"
                        >
                          <Check className="w-2 h-2 text-white" />
                        </motion.div>
                      )}
                      {/* Hover Glow */}
                      <div className="absolute inset-0 rounded-full group-hover/color:shadow-[0_0_10px_rgba(255,255,255,0.5)] transition-shadow" />
                    </button>
                  ))}
                </div>
              </div>

              {/* Theme Mode Toggle */}
              <div className="flex items-center justify-between px-3 py-2 rounded-lg hover:bg-white/5 text-slate-400 hover:text-white transition-all text-xs group">
                <div className="flex items-center gap-3">
                  {themeMode === 'dark' ? <Moon className="w-4 h-4 text-slate-500 group-hover:text-primary" /> : 
                   themeMode === 'light' ? <Sun className="w-4 h-4 text-slate-500 group-hover:text-primary" /> : 
                   <Monitor className="w-4 h-4 text-slate-500 group-hover:text-primary" />}
                  <span className="font-medium">{t.mode}</span>
                </div>
                <div className="flex bg-black/40 p-1 rounded-lg border border-white/5 shadow-inner">
                  {(['light', 'dark', 'auto'] as const).map((m) => (
                    <button
                      key={m}
                      onClick={() => onThemeModeChange(m)}
                      className={cn(
                        "p-1.5 rounded-md transition-all duration-200 relative group/mode",
                        themeMode === m 
                          ? "text-white" 
                          : "text-slate-600 hover:text-slate-400 hover:bg-white/5"
                      )}
                      title={m}
                    >
                      <div className="relative z-10">
                        {m === 'light' ? <Sun className="w-3.5 h-3.5" /> : 
                         m === 'dark' ? <Moon className="w-3.5 h-3.5" /> : 
                         <Monitor className="w-3.5 h-3.5" />}
                      </div>
                      {themeMode === m && (
                        <motion.div 
                          layoutId="activeMode"
                          className="absolute inset-0 bg-white/10 border border-white/20 rounded-md shadow-[0_0_10px_rgba(255,255,255,0.05)]"
                          transition={{ type: "spring", bounce: 0.2, duration: 0.6 }}
                        />
                      )}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>
      </nav>

      <div className="p-4 border-t border-white/5 space-y-2">
        {user && (
          <div className="px-4 py-3 mb-2 bg-white/5 rounded-xl border border-white/5 flex items-center gap-3">
            <div className="w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center overflow-hidden border border-primary/30">
              {user.user_metadata?.avatar_url ? (
                <img src={user.user_metadata.avatar_url} alt="Avatar" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
              ) : (
                <span className="text-[10px] font-bold text-primary">{user.email?.substring(0, 2).toUpperCase()}</span>
              )}
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-xs font-bold text-white truncate">{user.user_metadata?.full_name || user.email?.split('@')[0]}</p>
              <p className="text-[9px] text-slate-500 truncate">{t.discord_user || "Discord User"}</p>
            </div>
          </div>
        )}

        {/* Support & Feedback Section */}
        <p className="px-4 text-[10px] font-bold text-slate-500 uppercase tracking-[0.2em] mb-1">{t.support_links || "Support & Links"}</p>
        
        <a 
          href="https://discord.gg/QVtKkAP7Aw" 
          target="_blank" 
          rel="noopener noreferrer"
          className={cn(
            "w-full justify-start gap-3 h-11 transition-all group flex items-center px-4 rounded-lg text-slate-400 hover:text-white hover:bg-[#5865F2]/10 border border-transparent hover:border-[#5865F2]/30"
          )}
        >
          <div className="w-8 h-8 rounded-lg bg-white/5 flex items-center justify-center group-hover:bg-[#5865F2] transition-colors">
            <MessageCircle className="w-4 h-4" />
          </div>
          <span className="text-sm font-medium">{t.discord_support || "Discord Support"}</span>
        </a>

        <Button 
          type="button"
          variant="ghost" 
          className="w-full justify-start gap-3 text-slate-500 hover:text-rose-400 hover:bg-rose-400/5 h-11 transition-all group relative z-50"
          onClick={async () => {
            await supabase.auth.signOut();
            window.location.reload();
          }}
        >
          <div className="w-8 h-8 rounded-lg bg-white/5 flex items-center justify-center group-hover:bg-rose-500/20 transition-colors">
            <LogOut className="w-4 h-4" />
          </div>
          <span className="text-sm font-medium">{t.logout}</span>
        </Button>
      </div>
    </aside>
  );
}
