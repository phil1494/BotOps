import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  User, 
  Settings, 
  Globe, 
  Palette, 
  Moon, 
  LogOut, 
  ChevronRight, 
  ChevronLeft, 
  Check,
  Circle
} from "lucide-react";
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuTrigger,
  DropdownMenuSeparator,
  DropdownMenuLabel
} from "@/components/ui/dropdown-menu";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Language, TranslationType } from "@/src/lib/translations";
import { cn } from "@/src/lib/utils";

interface UserMenuProps {
  user: any;
  onLogout: () => void;
  onViewChange: (view: string) => void;
  language: Language;
  onLanguageChange: (lang: Language) => void;
  themeColor: string;
  onThemeColorChange: (color: string) => void;
  themeMode: 'auto' | 'light' | 'dark';
  onThemeModeChange: (mode: 'auto' | 'light' | 'dark') => void;
  t: TranslationType;
}

type MenuState = 'main' | 'language' | 'colors' | 'mode';

export function UserMenu({ 
  user, 
  onLogout, 
  onViewChange,
  language, 
  onLanguageChange, 
  themeColor, 
  onThemeColorChange, 
  themeMode, 
  onThemeModeChange,
  t 
}: UserMenuProps) {
  const [currentView, setCurrentView] = useState<'main' | 'language' | 'colors' | 'mode'>('main');

  const handleAction = (action: string, callback?: () => void) => {
    console.log(`DEBUG: UserMenu Action -> ${action}`);
    // alert(`DEBUG: Klick auf ${action} funktioniert!`); 
    if (callback) callback();
  };

  const languages: { label: string, code: Language, flag: string }[] = [
    { label: "العربية", code: 'ar', flag: "AR" },
    { label: "Deutsch", code: 'de', flag: "DE" },
    { label: "English", code: 'en', flag: "US" },
    { label: "Español", code: 'es', flag: "ES" },
    { label: "Français", code: 'fr', flag: "FR" },
    { label: "हिन्दी", code: 'hi', flag: "HI" },
    { label: "Italiano", code: 'it', flag: "IT" },
    { label: "日本語", code: 'ja', flag: "JA" },
    { label: "한국어", code: 'ko', flag: "KO" },
    { label: "Nederlands", code: 'nl', flag: "NL" },
    { label: "Português", code: 'pt', flag: "PT" },
    { label: "Русский", code: 'ru', flag: "RU" },
    { label: "Türkçe", code: 'tr', flag: "TR" },
    { label: "Українська", code: 'uk', flag: "UK" },
    { label: "Tiếng Việt", code: 'vi', flag: "VI" },
    { label: "中文", code: 'zh', flag: "ZH" },
  ];

  const colors = [
    { name: t.red, value: 'red', hex: '#ef4444' },
    { name: t.pink, value: 'pink', hex: '#ec4899' },
    { name: t.violet, value: 'violet', hex: '#8b5cf6' },
    { name: t.blue, value: 'blue', hex: '#3b82f6' },
    { name: t.green, value: 'green', hex: '#10b981' },
    { name: t.yellow, value: 'yellow', hex: '#eab308' },
    { name: t.orange, value: 'orange', hex: '#f97316' },
  ];

  const modes: { label: string, value: 'auto' | 'light' | 'dark' }[] = [
    { label: t.auto, value: 'auto' },
    { label: t.light, value: 'light' },
    { label: t.dark, value: 'dark' },
  ];

  return (
    <DropdownMenu onOpenChange={(open) => !open && setCurrentView('main')}>
      <DropdownMenuTrigger className={cn(
        "relative h-10 w-10 rounded-full p-0 hover:bg-white/5 flex items-center justify-center transition-all border-2 border-primary/20 hover:border-primary/50 outline-none cursor-pointer"
      )}>
        <Avatar className="h-10 w-10">
          <AvatarImage src={user?.user_metadata?.avatar_url || ""} alt={user?.user_metadata?.full_name || "User"} />
          <AvatarFallback className="bg-primary/10 text-primary font-bold">
            {user?.user_metadata?.full_name?.substring(0, 2).toUpperCase() || "US"}
          </AvatarFallback>
        </Avatar>
      </DropdownMenuTrigger>
      <DropdownMenuContent 
        className="card-glass border-white/10 bg-[#0a0b0e]/95 backdrop-blur-xl p-1 z-[9999] absolute" 
        align="end" 
        sideOffset={8}
      >
        {currentView === 'main' && (
          <div key="main-menu" className="w-56">
            <DropdownMenuItem 
              className="gap-2 cursor-pointer py-2.5"
              onSelect={(e) => {
                e.preventDefault();
                handleAction('Profile', () => onViewChange('profile'));
              }}
            >
              <User className="w-4 h-4" />
              <span>{t.profile}</span>
            </DropdownMenuItem>
            <DropdownMenuItem 
              className="gap-2 cursor-pointer py-2.5"
              onSelect={(e) => {
                e.preventDefault();
                handleAction('Settings', () => onViewChange('settings'));
              }}
            >
              <Settings className="w-4 h-4" />
              <span>{t.settings}</span>
            </DropdownMenuItem>
            
            <DropdownMenuSeparator className="bg-white/5" />
            
            <DropdownMenuItem 
              className="flex items-center justify-between cursor-pointer py-2.5"
              onSelect={(e) => { 
                e.preventDefault(); 
                handleAction('Language Menu', () => setCurrentView('language'));
              }}
            >
              <div className="flex items-center gap-2">
                <Globe className="w-4 h-4" />
                <span>{t.language}</span>
              </div>
              <div className="flex items-center gap-1 text-[10px] text-slate-500 font-bold">
                {language.toUpperCase()}
                <ChevronRight className="w-3 h-3" />
              </div>
            </DropdownMenuItem>

            <DropdownMenuItem 
              className="flex items-center justify-between cursor-pointer py-2.5"
              onSelect={(e) => { 
                e.preventDefault(); 
                handleAction('Colors Menu', () => setCurrentView('colors'));
              }}
            >
              <div className="flex items-center gap-2">
                <Palette className="w-4 h-4" />
                <span>{t.colors}</span>
              </div>
              <div className="flex items-center gap-1">
                <div className="w-3 h-3 rounded-full bg-primary shadow-[0_0_8px_rgba(var(--primary),0.5)]" />
                <ChevronRight className="w-3 h-3 text-slate-500" />
              </div>
            </DropdownMenuItem>

            <DropdownMenuItem 
              className="flex items-center justify-between cursor-pointer py-2.5"
              onSelect={(e) => { 
                e.preventDefault(); 
                handleAction('Mode Menu', () => setCurrentView('mode'));
              }}
            >
              <div className="flex items-center gap-2">
                <Moon className="w-4 h-4" />
                <span>{t.mode}</span>
              </div>
              <div className="flex items-center gap-1 text-[10px] text-slate-500 font-bold uppercase">
                {t[themeMode as keyof TranslationType] || themeMode}
                <ChevronRight className="w-3 h-3" />
              </div>
            </DropdownMenuItem>

            <DropdownMenuSeparator className="bg-white/5" />
            
            <DropdownMenuItem 
              className="gap-2 cursor-pointer py-2.5 text-rose-400 focus:text-rose-400 focus:bg-rose-400/10" 
              onSelect={() => handleAction('Logout', onLogout)}
            >
              <LogOut className="w-4 h-4" />
              <span>{t.logout}</span>
            </DropdownMenuItem>
          </div>
        )}

        {currentView === 'language' && (
          <div key="language-menu" className="w-56">
            <DropdownMenuItem 
              className="flex items-center gap-2 px-2 py-2 mb-1 cursor-pointer hover:bg-white/5 rounded-sm transition-colors focus:bg-white/5"
              onSelect={(e) => {
                e.preventDefault();
                handleAction('Back to Main', () => setCurrentView('main'));
              }}
            >
              <ChevronLeft className="w-4 h-4 text-slate-500" />
              <span className="text-sm font-bold">{t.language}</span>
            </DropdownMenuItem>
            <DropdownMenuSeparator className="bg-white/5" />
            <div className="max-h-[300px] overflow-y-auto pr-1 custom-scrollbar">
              {languages.map((lang) => (
                <DropdownMenuItem 
                  key={lang.code}
                  className="flex items-center justify-between cursor-pointer py-2.5"
                  onSelect={(e) => {
                    e.preventDefault();
                    handleAction(`Language: ${lang.code}`, () => onLanguageChange(lang.code));
                  }}
                >
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-medium">{lang.label}</span>
                    <span className="text-[10px] text-slate-500 font-bold uppercase">{lang.flag}</span>
                  </div>
                  {language === lang.code && <Check className="w-4 h-4 text-primary" />}
                </DropdownMenuItem>
              ))}
            </div>
          </div>
        )}

        {currentView === 'colors' && (
          <div key="colors-menu" className="w-56">
            <DropdownMenuItem 
              className="flex items-center gap-2 px-2 py-2 mb-1 cursor-pointer hover:bg-white/5 rounded-sm transition-colors focus:bg-white/5"
              onSelect={(e) => {
                e.preventDefault();
                handleAction('Back to Main', () => setCurrentView('main'));
              }}
            >
              <ChevronLeft className="w-4 h-4 text-slate-500" />
              <span className="text-sm font-bold">{t.colors}</span>
            </DropdownMenuItem>
            <DropdownMenuSeparator className="bg-white/5" />
            {colors.map((color) => (
              <DropdownMenuItem 
                key={color.value}
                className="flex items-center justify-between cursor-pointer py-2.5"
                onSelect={(e) => {
                  e.preventDefault();
                  handleAction(`Color: ${color.value}`, () => onThemeColorChange(color.value));
                }}
              >
                <div className="flex items-center gap-3">
                  <div className="w-4 h-4 rounded-full border border-white/10" style={{ backgroundColor: color.hex }} />
                  <span className="text-sm">{color.name}</span>
                </div>
                {themeColor === color.value && <Check className="w-4 h-4 text-primary" />}
              </DropdownMenuItem>
            ))}
          </div>
        )}

        {currentView === 'mode' && (
          <div key="mode-menu" className="w-56">
            <DropdownMenuItem 
              className="flex items-center gap-2 px-2 py-2 mb-1 cursor-pointer hover:bg-white/5 rounded-sm transition-colors focus:bg-white/5"
              onSelect={(e) => {
                e.preventDefault();
                handleAction('Back to Main', () => setCurrentView('main'));
              }}
            >
              <ChevronLeft className="w-4 h-4 text-slate-500" />
              <span className="text-sm font-bold">{t.mode}</span>
            </DropdownMenuItem>
            <DropdownMenuSeparator className="bg-white/5" />
            {modes.map((m) => (
              <DropdownMenuItem 
                key={m.value}
                className="flex items-center justify-between cursor-pointer py-2.5"
                onSelect={(e) => {
                  e.preventDefault();
                  handleAction(`Mode: ${m.value}`, () => onThemeModeChange(m.value));
                }}
              >
                <span className="text-sm">{m.label}</span>
                {themeMode === m.value && <Check className="w-4 h-4 text-primary" />}
              </DropdownMenuItem>
            ))}
          </div>
        )}
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
