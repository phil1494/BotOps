import { useState, useEffect, useCallback, useMemo } from "react";
import { motion, AnimatePresence } from "motion/react";
import { v4 as uuidv4 } from "uuid";
import { 
  AlertCircle,
  Bell,
  Search,
  Globe,
  Menu,
  X
} from "lucide-react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Input } from "@/components/ui/input";
import {
  AlertDialogAction,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialog,
} from "@/components/ui/alert-dialog";
import { TooltipProvider } from "@/components/ui/tooltip";

// Types & Views
import { Bot, BotAnalysis } from "./types";
import { Sidebar } from "./components/Sidebar";
import { Login } from "./components/Login";
import { DashboardView } from "./components/views/DashboardView";
import { DeepAnalysisView } from "./components/views/DeepAnalysisView";
import { BotManagerView } from "./components/views/BotManagerView";
import { SettingsView } from "./components/views/SettingsView";
import { ProfileView } from "./components/views/ProfileView";
import { BotDetailView } from "./components/views/BotDetailView";
import { InfoView } from "./components/views/InfoView";
import { Language, translations } from "./lib/translations";
import { supabase } from "./lib/supabaseClient";
import { analyzeBotLog, generateMoodSummary, generateSecurityChecklist } from "./services/geminiService";

export default function App() {
  const [session, setSession] = useState<any>(null);
  const [activeView, setActiveView] = useState("dashboard");
  const [selectedBotId, setSelectedBotId] = useState<string | null>(null);
  const [bots, setBots] = useState<Bot[]>([]);
  const [history, setHistory] = useState<BotAnalysis[]>([]);
  const [totalAnalyses, setTotalAnalyses] = useState(0);
  const [notificationsCount, setNotificationsCount] = useState(0);
  const [isLoading, setIsLoading] = useState(false);
  const [initError, setInitError] = useState<string | null>(null);
  const [highContrast, setHighContrast] = useState(() => {
    const saved = localStorage.getItem("botops_high_contrast");
    return saved ? JSON.parse(saved) : false;
  });
  const [language, setLanguage] = useState<Language>(() => {
    const saved = localStorage.getItem("botops_language");
    return (saved as Language) || 'de';
  });
  const [themeColor, setThemeColor] = useState(() => {
    return localStorage.getItem("botops_theme_color") || 'blue';
  });
  const [themeMode, setThemeMode] = useState<'auto' | 'light' | 'dark'>(() => {
    return (localStorage.getItem("botops_theme_mode") as any) || 'dark';
  });
  const [starterKitDownloaded, setStarterKitDownloaded] = useState(() => {
    return localStorage.getItem("botops_starter_kit_downloaded") === "true";
  });
  
  const t = translations[language];

  // Persist settings
  useEffect(() => {
    localStorage.setItem("botops_starter_kit_downloaded", starterKitDownloaded.toString());
  }, [starterKitDownloaded]);
  useEffect(() => {
    localStorage.setItem("botops_high_contrast", JSON.stringify(highContrast));
  }, [highContrast]);

  useEffect(() => {
    localStorage.setItem("botops_language", language);
  }, [language]);

  useEffect(() => {
    localStorage.setItem("botops_theme_color", themeColor);
    document.documentElement.setAttribute('data-theme', themeColor);
    // Also update sidebar primary for consistency if needed
    document.documentElement.style.setProperty('--sidebar-primary', `var(--primary)`);
    document.documentElement.style.setProperty('--sidebar-ring', `var(--primary)`);
  }, [themeColor]);

  useEffect(() => {
    localStorage.setItem("botops_theme_mode", themeMode);
    const root = document.documentElement;
    if (themeMode === 'auto') {
      const isDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
      root.classList.toggle('dark', isDark);
    } else {
      root.classList.toggle('dark', themeMode === 'dark');
    }
  }, [themeMode]);
  
  // Notifications State
  const [notifications, setNotifications] = useState<any[]>([]);
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [showNotifications, setShowNotifications] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");

  // Update notifications when language changes
  useEffect(() => {
    // In production, notifications would be fetched from a real source
    setNotifications([]);
  }, [language, t]);

  // Auth Listener & Initialization
  useEffect(() => {
    async function initAuth() {
      const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
      const supabaseKey = import.meta.env.VITE_SUPABASE_ANON_KEY;
      const geminiKey = import.meta.env.VITE_GEMINI_API_KEY;
      
      // Developer Bypass / Mock Auth for AI Studio Sandbox
      const isDev = import.meta.env.DEV;
      const isAiStudio = window.location.hostname.includes('run.app') || 
                         window.location.hostname.includes('googleusercontent.com') ||
                         document.referrer.includes('aistudio.google.com');

      if (isAiStudio || isDev) {
        console.log("🛠️ Dev Mode / AI Studio detected: Using Mock Auth");
        const mockSession = {
          user: {
            id: "00000000-0000-0000-0000-000000000000",
            email: "dev@botops.io",
            user_metadata: {
              full_name: "Developer Admin",
              avatar_url: "https://picsum.photos/seed/dev/200/200"
            }
          },
          access_token: "mock-token",
          expires_at: 9999999999
        };
        setSession(mockSession);
        return;
      }

      if (!supabaseUrl || !supabaseKey || !geminiKey) {
        setInitError("Konfigurationsfehler: Bitte überprüfe deine Umgebungsvariablen in Netlify (VITE_SUPABASE_URL, VITE_SUPABASE_ANON_KEY, VITE_GEMINI_API_KEY).");
        return;
      }

      try {
        const { data: { session }, error } = await supabase.auth.getSession();
        if (error) throw error;
        setSession(session);
        
        const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
          setSession(session);
        });

        return () => subscription.unsubscribe();
      } catch (err: any) {
        console.error("Initialization Error:", err);
      }
    }

    initAuth();
  }, []);

  // Load Data from Supabase
  useEffect(() => {
    if (!session) {
      if (!isLoading) setIsLoading(false);
      return;
    }

    async function fetchBots() {
      setIsLoading(true);
      try {
        const { data, error } = await supabase
          .from("cluster_stats")
          .select("*")
          .eq("user_id", session.user.id);
        
        if (error) throw error;
        
        if (data) {
          const now = new Date();
          setBots(data.map((b: any) => {
            const lastPingDate = new Date(b.updated_at);
            const diffMinutes = (now.getTime() - lastPingDate.getTime()) / (1000 * 60);
            const isOffline = diffMinutes > 2;

            return {
              id: b.id,
              tracking_key: b.id,
              username: b.name?.split('|')[0] || "Cluster Instance",
              discord_id: b.name?.split('|')[1] || b.id.substring(0, 8),
              discriminator: "0000",
              avatar: b.avatar_url || null,
              guild_count: Number(b.guild_count) || 0,
              status: isOffline ? "offline" : (b.status || "offline"),
              cpu_usage: parseFloat(b.cpu_usage) || 0,
              ram_usage: b.ram_usage || "0MB",
              uptime: b.uptime || 0,
              last_ping: b.updated_at
            };
          }));
        }
      } catch (error) {
        console.error("Failed to fetch bots:", error);
      } finally {
        setIsLoading(false);
      }
    }

    const savedHistory = localStorage.getItem(`botops_history_${session.user.id}`);
    if (savedHistory) setHistory(JSON.parse(savedHistory));
    else setHistory([]);

    fetchBots();

    async function fetchAnalysesCount() {
      const { count, error } = await supabase
        .from('analyses')
        .select('*', { count: 'exact', head: true })
        .eq('user_id', session.user.id);
      if (!error && count !== null) setTotalAnalyses(count);
    }
    fetchAnalysesCount();
  }, [session]);

  // Real-time Subscriptions
  useEffect(() => {
    if (!session) return;

    const channel = supabase
      .channel(`public:cluster_stats:${session.user.id}`)
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'cluster_stats', filter: `user_id=eq.${session.user.id}` },
        (payload) => {
          if (payload.eventType === 'INSERT') {
            const b = payload.new;
            setBots(prev => {
              if (prev.some(bot => bot.id === b.id)) return prev;
              return [...prev, {
                id: b.id,
                tracking_key: b.id,
                username: b.name?.split('|')[0] || "Cluster Instance",
                discord_id: b.name?.split('|')[1] || b.id.substring(0, 8),
                discriminator: "0000",
                avatar: b.avatar_url || null,
                guild_count: Number(b.guild_count) || 0,
                status: b.status || "offline",
                cpu_usage: parseFloat(b.cpu_usage) || 0,
                ram_usage: b.ram_usage || "0MB",
                uptime: b.uptime || 0,
                last_ping: b.updated_at
              }];
            });
          } else if (payload.eventType === 'UPDATE') {
            const b = payload.new;
            const now = new Date();
            const lastPingDate = new Date(b.updated_at);
            const diffMinutes = (now.getTime() - lastPingDate.getTime()) / (1000 * 60);
            const isOffline = diffMinutes > 2;

            setBots(prev => prev.map(bot => bot.id === b.id ? {
              ...bot,
              username: b.name?.split('|')[0] || bot.username,
              discord_id: b.name?.split('|')[1] || bot.discord_id,
              status: isOffline ? "offline" : (b.status || "offline"),
              cpu_usage: parseFloat(b.cpu_usage),
              ram_usage: b.ram_usage,
              uptime: b.uptime,
              last_ping: b.updated_at,
              guild_count: Number(b.guild_count) || 0
            } : bot));

            // Alert Logic: High CPU
            if (parseFloat(b.cpu_usage) > 90) {
              const alert = {
                id: Date.now(),
                title: `Kritische CPU: ${b.name || 'Cluster'}`,
                message: `Cluster ${b.name || 'Instance'} hat eine CPU-Auslastung von ${parseFloat(b.cpu_usage).toFixed(1)}%!`,
                type: 'warning',
                time: new Date().toLocaleTimeString()
              };
              setNotifications(prev => [alert, ...prev]);
              setNotificationsCount(c => c + 1);
            }
          } else if (payload.eventType === 'DELETE') {
            setBots(prev => prev.filter(bot => bot.id === payload.old.id));
          }
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [session]);

  // Periodic Offline Check (Every 30 seconds)
  useEffect(() => {
    if (bots.length === 0) return;

    const interval = setInterval(() => {
      const now = new Date();
      setBots(prev => prev.map(bot => {
        if (!bot.last_ping) return bot;
        const lastPingDate = new Date(bot.last_ping);
        const diffMinutes = (now.getTime() - lastPingDate.getTime()) / (1000 * 60);
        
        if (diffMinutes > 2 && bot.status !== 'offline') {
          return { ...bot, status: 'offline' };
        }
        return bot;
      }));
    }, 30000);

    return () => clearInterval(interval);
  }, [bots.length]);

  // Save History to localStorage
  useEffect(() => {
    if (session) {
      localStorage.setItem(`botops_history_${session.user.id}`, JSON.stringify(history));
    }
  }, [history, session]);

  const handleAddBot = async (name: string) => {
    if (!session) return;
    try {
      const newId = uuidv4();
      const { data, error } = await supabase
        .from("cluster_stats")
        .insert([
          { 
            id: newId,
            name, 
            user_id: session.user.id,
            status: "offline",
            guild_count: 0,
            cpu_usage: 0,
            ram_usage: "0MB"
          }
        ])
        .select()
        .single();

      if (error) throw error;

      const newBot: Bot = {
        id: data.id,
        tracking_key: data.id,
        username: data.name,
        name: data.name, // The custom name is stored in the 'name' column
        discriminator: "0000",
        avatar: null,
        guild_count: 0,
        status: "offline",
        cpu_usage: 0,
        ram_usage: "0MB",
        uptime: 0
      };

      setBots(prev => [...prev, newBot]);
      return data.id;
    } catch (error: any) {
      console.error("Add Bot Error Details:", error);
      throw error;
    }
  };

  // API Preparation: Update Bot Stats
  const updateBotStats = useCallback((trackingKey: string, stats: { cpu: number, ram: string, status: "online" | "offline" | "warning" }) => {
    setBots(prev => prev.map(bot => {
      if (bot.tracking_key === trackingKey) {
        return {
          ...bot,
          cpu_usage: stats.cpu,
          ram_usage: stats.ram,
          status: stats.status,
          last_ping: new Date().toISOString()
        };
      }
      return bot;
    }));
  }, []);

  // Expose updateBotStats globally for "external API" simulation/testing
  useEffect(() => {
    (window as any).updateBotStats = updateBotStats;
  }, [updateBotStats]);

  const handleRemoveBot = async (id: string) => {
    if (!session) return;
    try {
      const { error } = await supabase.from("cluster_stats").delete().eq("id", id);
      if (error) throw error;
      setBots(prev => prev.filter(b => b.id !== id));
    } catch (error) {
      console.error("Failed to remove bot:", error);
    }
  };

  const handleAnalyzeLog = async (log: string) => {
    const analysis = await analyzeBotLog(log);
    const analysisWithTime = {
      ...analysis,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };
    
    // Save to Supabase
    if (session) {
      try {
        await supabase.from('analyses').insert([{
          user_id: session.user.id,
          log_content: log,
          analysis_result: analysisWithTime
        }]);
        setTotalAnalyses(prev => prev + 1);
      } catch (err) {
        console.error("Failed to save analysis to Supabase:", err);
      }
    }

    setHistory(prev => [analysisWithTime, ...prev].slice(0, 10));
    
    if (bots.length > 0) {
      const mood = await generateMoodSummary(log);
      setBots(prev => prev.map((b, i) => i === 0 ? { ...b, mood_summary: mood, status: analysis.bot_status === "online" ? "online" : "warning" } : b));
    }

    return analysisWithTime;
  };

  const clearHistory = () => {
    setHistory([]);
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
  };

  const scanForTokens = (input: string): boolean => {
    const tokenRegex = /[M-Z][A-Za-z\d]{23}\.[\w-]{6}\.[\w-]{27}/;
    return tokenRegex.test(input);
  };

  const removeNotification = (id: number) => {
    setNotifications(prev => prev.filter(n => n.id !== id));
  };

  const filteredBots = bots.filter(bot => 
    bot.username.toLowerCase().includes(searchQuery.toLowerCase()) ||
    bot.id.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const totalServers = useMemo(() => {
    return bots.reduce((sum, bot) => sum + (Number(bot.guild_count) || 0), 0);
  }, [bots]);

  const avgCpu = useMemo(() => {
    if (bots.length === 0) return 0;
    return bots.reduce((sum, bot) => sum + (bot.cpu_usage || 0), 0) / bots.length;
  }, [bots]);

  const totalRam = useMemo(() => {
    return bots.reduce((sum, bot) => {
      const val = parseFloat(bot.ram_usage || "0");
      return sum + (isNaN(val) ? 0 : val);
    }, 0);
  }, [bots]);

  const renderView = () => {
    if (selectedBotId) {
      const bot = bots.find(b => b.id === selectedBotId);
      if (bot) return <BotDetailView bot={bot} onBack={() => setSelectedBotId(null)} t={t} />;
    }

    switch (activeView) {
      case "dashboard": return (
        <DashboardView 
          bots={filteredBots} 
          totalServers={totalServers} 
          avgCpu={avgCpu}
          totalRam={totalRam}
          onSelectBot={setSelectedBotId} 
          onAddBotClick={() => setActiveView("manager")} 
          t={t} 
          starterKitDownloaded={starterKitDownloaded}
        />
      );
      case "analysis": 
        return (
          <DeepAnalysisView 
            history={history} 
            totalAnalyses={totalAnalyses}
            onAnalyze={handleAnalyzeLog} 
            onClearHistory={clearHistory}
            scanForTokens={scanForTokens}
            copyToClipboard={copyToClipboard}
            t={t}
          />
        );
      case "manager": return <BotManagerView bots={bots} onAddBot={handleAddBot} onRemoveBot={handleRemoveBot} onGoToAnalysis={() => setActiveView("analysis")} t={t} />;
      case "info": return (
        <InfoView 
          t={t} 
          onGoToDashboard={() => setActiveView("dashboard")} 
          bots={bots} 
          userId={session?.user?.id} 
          onDownload={() => setStarterKitDownloaded(true)}
        />
      );
      case "settings": return (
        <SettingsView 
          onClearData={() => { setBots([]); setHistory([]); localStorage.clear(); }} 
          highContrast={highContrast}
          setHighContrast={setHighContrast}
          language={language}
          setLanguage={setLanguage}
          t={t}
        />
      );
      case "profile": return <ProfileView user={session.user} t={t} />;
      default: return (
        <DashboardView 
          bots={filteredBots} 
          totalServers={totalServers} 
          avgCpu={avgCpu}
          totalRam={totalRam}
          onSelectBot={setSelectedBotId} 
          onAddBotClick={() => setActiveView("manager")} 
          t={t} 
          starterKitDownloaded={starterKitDownloaded}
        />
      );
    }
  };

  if (initError) {
    return (
      <div className="h-screen flex items-center justify-center bg-[#050609] p-6">
        <div className="max-w-md w-full bg-rose-500/10 border border-rose-500/20 rounded-2xl p-8 text-center">
          <AlertCircle className="w-12 h-12 text-rose-500 mx-auto mb-4" />
          <h2 className="text-xl font-bold text-white mb-2">Konfiguration fehlt</h2>
          <p className="text-slate-400 text-sm mb-6 leading-relaxed">{initError}</p>
          <Button 
            className="bg-rose-500 hover:bg-rose-500/90 text-white w-full"
            onClick={() => window.location.reload()}
          >
            Neu laden
          </Button>
        </div>
      </div>
    );
  }

  if (!session) {
    return <Login />;
  }

  return (
    <TooltipProvider>
      <div className={cn(
        "flex min-h-screen bg-[#050505] text-white font-sans selection:bg-primary/30 selection:text-white relative overflow-hidden transition-all duration-300",
        highContrast && "contrast-[1.15] saturate-[1.2] brightness-[1.1]"
      )}>
        {/* Background Radial Gradient */}
        <div className="absolute top-[-10%] right-[-10%] w-[50%] h-[50%] bg-primary/10 blur-[120px] rounded-full pointer-events-none" />
        <div className="absolute bottom-[-10%] left-[-10%] w-[40%] h-[40%] bg-indigo-500/10 blur-[120px] rounded-full pointer-events-none" />
        
        {/* Mobile Sidebar Overlay */}
        <AnimatePresence>
          {isSidebarOpen && (
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsSidebarOpen(false)}
              className="fixed inset-0 bg-black/60 backdrop-blur-sm z-[60] lg:hidden"
            />
          )}
        </AnimatePresence>

        {/* Sidebar */}
        <div className={cn(
          "fixed inset-y-0 left-0 z-[70] lg:relative lg:z-50 transition-transform duration-300 transform lg:translate-x-0",
          isSidebarOpen ? "translate-x-0" : "-translate-x-full"
        )}>
          <Sidebar 
            activeView={activeView} 
            setActiveView={(view) => {
              setActiveView(view);
              setIsSidebarOpen(false);
              if (view === "analysis") setNotificationsCount(0);
            }} 
            notificationsCount={notificationsCount}
            onClose={() => setIsSidebarOpen(false)}
            t={t}
            language={language}
            onLanguageChange={setLanguage}
            themeColor={themeColor}
            onThemeColorChange={setThemeColor}
            themeMode={themeMode}
            onThemeModeChange={setThemeMode}
          />
        </div>

        {/* Main Content */}
        <main className="flex-1 flex flex-col relative z-0 min-w-0 h-screen overflow-hidden">
          {/* Header */}
          <header className="h-16 border-b border-white/5 bg-[#050505]/80 backdrop-blur-md flex items-center justify-between px-4 lg:px-8 sticky top-0 z-40">
            <div className="flex items-center gap-4">
              <Button 
                variant="ghost" 
                size="icon" 
                className="lg:hidden text-slate-400 hover:text-white"
                onClick={() => setIsSidebarOpen(true)}
              >
                <Menu className="w-6 h-6" />
              </Button>
              <div className="flex items-center gap-2">
                <div className="hidden sm:flex items-center gap-2 px-3 py-1 bg-white/5 rounded-full border border-white/10">
                  <Globe className="w-3 h-3 text-primary" />
                  <span className="text-[10px] font-bold uppercase tracking-widest text-slate-400">{t.global_cluster}</span>
                  <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 shadow-[0_0_8px_rgba(16,185,129,0.5)]" />
                </div>
                <div className="hidden md:block h-4 w-px bg-white/10" />
                <div className="hidden md:flex items-center gap-2 relative group">
                  <Search className="w-4 h-4 text-slate-500 absolute left-3 pointer-events-none group-focus-within:text-primary transition-colors" />
                  <Input 
                    placeholder={t.quick_search}
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="h-9 w-64 bg-white/5 border-white/10 pl-9 pr-10 text-xs text-white placeholder:text-slate-500 focus:bg-white/10 focus:border-primary/50 transition-all"
                  />
                  <div className="absolute right-3 flex items-center gap-1 pointer-events-none">
                    <Badge variant="outline" className="text-[9px] border-white/10 text-slate-600 bg-black/20 px-1 h-4">⌘K</Badge>
                  </div>
                </div>
              </div>
            </div>

            <div className="flex items-center gap-4">
              {/* Notifications removed from header for cleaner production look or moved to real system */}
              
              <div className="relative">
                <Button 
                  variant="ghost" 
                  size="icon" 
                  className={cn(
                    "h-9 w-9 text-slate-400 hover:text-white hover:bg-white/5 relative transition-all",
                    showNotifications && "bg-white/10 text-white"
                  )}
                  onClick={() => {
                    setShowNotifications(!showNotifications);
                    if (!showNotifications) setNotificationsCount(0);
                  }}
                >
                  <Bell className="w-5 h-5" />
                  {(notificationsCount > 0 || notifications.length > 0) && (
                    <div className="absolute top-2 right-2 w-2 h-2 bg-primary rounded-full border-2 border-[#050505]" />
                  )}
                </Button>

                <AnimatePresence>
                  {showNotifications && (
                    <>
                      <motion.div 
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        exit={{ opacity: 0 }}
                        className="fixed inset-0 z-[60]"
                        onClick={() => setShowNotifications(false)}
                      />
                      <motion.div
                        initial={{ opacity: 0, y: 10, scale: 0.95 }}
                        animate={{ opacity: 1, y: 0, scale: 1 }}
                        exit={{ opacity: 0, y: 10, scale: 0.95 }}
                        className="absolute right-0 mt-2 w-80 card-glass z-[70] overflow-hidden shadow-2xl"
                      >
                        <div className="p-4 border-b border-white/5 flex items-center justify-between bg-white/5">
                          <h3 className="text-sm font-bold text-white uppercase tracking-widest">{t.notifications}</h3>
                          <Badge variant="outline" className="text-[10px] border-primary/30 text-primary">{notifications.length}</Badge>
                        </div>
                        <ScrollArea className="max-h-[350px]">
                          <div className="divide-y divide-white/5">
                            {notifications.map((n) => (
                              <div key={n.id} className="p-4 hover:bg-white/5 transition-colors cursor-pointer group relative">
                                <div className="flex items-start gap-3">
                                  <div className={cn(
                                    "w-2 h-2 rounded-full mt-1.5 shrink-0",
                                    n.type === 'warning' ? 'bg-amber-500' : 
                                    n.type === 'success' ? 'bg-emerald-500' : 'bg-primary'
                                  )} />
                                  <div className="flex-1 min-w-0">
                                    <p className="text-xs font-bold text-white group-hover:text-primary transition-colors">{n.title}</p>
                                    <p className="text-[11px] text-slate-400 mt-0.5 leading-relaxed">{n.message}</p>
                                    <p className="text-[9px] text-slate-600 mt-1 font-mono">{n.time}</p>
                                  </div>
                                  <Button
                                    variant="ghost"
                                    size="icon"
                                    className="h-6 w-6 text-slate-600 hover:text-rose-500 opacity-0 group-hover:opacity-100 transition-all absolute top-2 right-2"
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      removeNotification(n.id);
                                    }}
                                  >
                                    <X className="w-3 h-3" />
                                  </Button>
                                </div>
                              </div>
                            ))}
                          </div>
                        </ScrollArea>
                        <div className="p-3 border-t border-white/5 bg-white/5 text-center">
                          <button 
                            className="text-[10px] font-bold text-slate-500 hover:text-white uppercase tracking-widest transition-colors"
                            onClick={() => {
                              setNotifications([]);
                              setNotificationsCount(0);
                            }}
                          >
                            {t.clear_all}
                          </button>
                        </div>
                      </motion.div>
                    </>
                  )}
                </AnimatePresence>
              </div>
            
            <div className="flex items-center gap-3 px-3 py-1.5 bg-white/5 rounded-full border border-white/10">
              <div className="w-7 h-7 rounded-full bg-primary/20 flex items-center justify-center overflow-hidden border border-primary/30">
                {session.user.user_metadata?.avatar_url ? (
                  <img src={session.user.user_metadata.avatar_url} alt="Avatar" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                ) : (
                  <span className="text-[10px] font-bold text-primary">{session.user.email?.substring(0, 2).toUpperCase()}</span>
                )}
              </div>
              <div className="hidden sm:block">
                <p className="text-[11px] font-bold text-white leading-none">{session.user.user_metadata?.full_name || session.user.email?.split('@')[0]}</p>
                <p className="text-[9px] text-slate-500 mt-0.5">Admin</p>
              </div>
            </div>
          </div>
        </header>

          {/* View Content */}
          <div className="flex-1 p-4 lg:p-6 overflow-y-auto relative z-0">
            <motion.div
              key={activeView}
              initial={{ opacity: 0, y: 4 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.15, ease: "easeOut" }}
            >
              {renderView()}
            </motion.div>
          </div>
        </main>
      </div>
    </TooltipProvider>
  );
}
