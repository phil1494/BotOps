export interface BotCommand {
  name: string;
  description: string;
  category?: string;
}

export interface Bot {
  id: string; // This will be the UUID from Supabase
  tracking_key: string; // The UUID for external API tracking
  discord_id?: string; // This will be the original Discord ID
  username: string;
  name: string | null; // The custom name given during registration
  discriminator: string;
  avatar: string | null;
  guild_count: number;
  status: "online" | "offline" | "warning";
  token?: string;
  mood_summary?: string;
  security_checklist?: string[];
  language_detected?: "python" | "javascript" | "unknown";
  commands?: BotCommand[];
  cpu_usage?: number;
  ram_usage?: string;
  uptime?: number;
  last_ping?: string;
}

export interface CodeGeneration {
  code: string;
  explanation: string;
  language: string;
}

export interface BotAnalysis {
  bot_status: "error" | "online" | "warning";
  analysis: string;
  fix_steps: string[];
  suggested_fix_code?: string;
  health_score: number;
  stats_insight: string;
  timestamp?: string;
}
